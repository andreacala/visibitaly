<div class="control-box">
    <fieldset>
        <legend>
            <?php
            _e('Create a drop-down menu with values taken from a spreadsheet.');
            echo ' ';
            printf(
                __('For more details, see %s'),
                '<a href="http://bossakov.eu/documentation/pvb-cf7-calculator-pro-' .
                    $pluginVersion .
                    '.pdf" target="_blank">' .
                    __('plugin documentation') .
                    '</a>'
            );
            ?>
        </legend>
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row"><?php echo esc_html( __( 'Field type', 'contact-form-7' ) ); ?></th>
                    <td>
                        <fieldset>
                            <legend class="screen-reader-text">
                                <?php echo esc_html( __( 'Field type', 'contact-form-7' ) ); ?>
                            </legend>
                            <label>
                                <input type="checkbox" name="required" />
                                <?php echo esc_html( __( 'Required field', 'contact-form-7' ) ); ?>
                            </label>
                        </fieldset>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                    </th>
                    <td>
                        <label><input
                            type="checkbox"
                            name="type:select"
                            id="type:select"
                            class="option type-selector"
                            value="on"
                            checked>
                        <?php echo esc_html(__(
                            'Drop-down list',
                            'pvb-cf7-calculator'
                        )); ?>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                    </th>
                    <td>
                        <label><input
                            type="checkbox"
                            name="type:checkbox"
                            id="type:checkbox"
                            class="option type-selector"
                            value="on">
                        <?php echo esc_html(__(
                            'Checkboxes',
                            'pvb-cf7-calculator'
                        )); ?>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                    </th>
                    <td>
                        <label><input
                            type="checkbox"
                            name="type:radio"
                            id="type:radio"
                            class="option type-selector"
                            value="on">
                        <?php echo esc_html(__(
                            'Radio buttons',
                            'pvb-cf7-calculator'
                        )); ?>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="<?php echo esc_attr( $args['content'] . '-name' ); ?>">
                            <?php echo esc_html( __( 'Name', 'contact-form-7' ) ); ?>
                        </label>
                    </th>
                    <td>
                        <input type="text" name="name" class="tg-name oneline" id="<?php
                            echo esc_attr( $args['content'] . '-name' );
                        ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php echo esc_html(__('Document path / URL', 'pvb-cf7-calculator')); ?>
                    </th>
                    <td>
                        <input type="text" name="values" class="documentvalue oneline" id="<?php
                            echo esc_attr($args['content'] . '-values');
                        ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php echo esc_html(__('Sheet number', 'pvb-cf7-calculator')); ?>
                    </th>
                    <td>
                        <input type="text" name="sheet" class="sheetvalue oneline option" id="<?php
                            echo esc_attr($args['content'] . '-sheet');
                        ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php echo esc_html(__('Cell range (e.g. A1-B10)', 'pvb-cf7-calculator')); ?>
                    </th>
                    <td>
                        <input type="text" name="cells" class="cellsvalue oneline option" id="<?php
                            echo esc_attr($args['content'] . '-cells');
                        ?>" />
                    </td>
                </tr>
                <tr>
                <th scope="row"><?php echo esc_html( __( 'Options', 'contact-form-7' ) ); ?></th>
                    <td>
                        <fieldset>
                            <label><input type="checkbox" name="multiple" class="option" /> <?php echo esc_html( __( 'Allow multiple selections', 'contact-form-7' ) ); ?></label><br />
                            <label><input type="checkbox" name="include_blank" class="option" /> <?php echo esc_html( __( 'Insert a blank item as the first option', 'contact-form-7' ) ); ?></label>
                        </fieldset>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="<?php echo esc_attr($args['content'] . '-id'); ?>"><?php
                            echo esc_html(__('Id attribute', 'pvb-cf7-calculator'));
                        ?></label>
                    </th>
                    <td>
                        <input type="text" name="id" class="idvalue oneline option" id="<?php
                            echo esc_attr($args['content'] . '-id');
                        ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="<?php echo esc_attr($args['content'] . '-class'); ?>"><?php
                            echo esc_html(__('Class attribute', 'pvb-cf7-calculator'));
                        ?></label>
                    </th>
                    <td>
                        <input type="text" name="class" class="classvalue oneline option" id="<?php
                            echo esc_attr($args['content'] . '-class');
                        ?>" />
                    </td>
                </tr>
            </tbody>
        </table>
    </fieldset>
</div>

<div class="insert-box">
    <input type="text" name="<?php echo $type; ?>" class="tag code" readonly="readonly" onfocus="this.select()" />

    <div class="submitbox">
    <input type="button" class="button button-primary insert-tag" value="<?php
        echo esc_attr( __( 'Insert Tag', 'contact-form-7' ) );
    ?>" />
    </div>

    <br class="clear" />

    <p class="description mail-tag">
        <label for="<?php echo esc_attr( $args['content'] . '-mailtag' ); ?>">
            <?php echo sprintf(esc_html(__( "To use the value input through this field in a mail field, you need to
                insert the corresponding mail-tag (%s) into the field on the Mail tab.", 'contact-form-7')),
                '<strong><span class="mail-tag"></span></strong>'
                );
            ?>
            <input type="text" class="mail-tag code hidden" readonly="readonly" id="<?php
                echo esc_attr( $args['content'] . '-mailtag' );
            ?>" />
        </label>
    </p>
</div>

<script>
jQuery(document).ready(function($) {
    $('.type-selector').click(function() {
        if ($(this).prop('checked')) {
            $('.type-selector').not(this).prop('checked', false);
            if ($(this).attr('name') == 'type:radio') {
                $('input[name=multiple]').closest('label').hide();
            } else {
                $('input[name=multiple]').closest('label').show();
            }
            if ($(this).attr('name') == 'type:select') {
                $('input[name=include_blank]').closest('label').show();
            } else {
                $('input[name=include_blank]').closest('label').hide();
            }
        }
    });
});
</script>