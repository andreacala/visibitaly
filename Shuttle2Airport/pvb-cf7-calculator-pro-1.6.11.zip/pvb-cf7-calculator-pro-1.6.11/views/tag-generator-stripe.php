<div class="control-box">
    <fieldset>
        <legend>
            <?php
            _e('Create a Stripe Checkout button that is displayed when the ' .
                ' calculation is done.');
            echo ' ';
            printf(
                __('For more details, see %s'),
                '<a href="' .
                    'http://bossakov.eu/documentation/pvb-cf7-calculator-pro-' .
                    $pluginVersion . '.pdf' . 
                    '" target="_blank">' .
                    __('plugin documentation') .
                    '</a>'
            );
            ?>
        </legend>
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row">
                        <label for="<?php
                        echo esc_attr($args['content'] . '-name');
                        ?>">
                            <?php
                            echo esc_html(__('Name', 'pvb-cf7-calculator'));
                            ?>
                        </label>
                    </th>
                    <td>
                        <input
                            type="text"
                            name="name"
                            class="tg-name oneline"
                            id="<?php
                            echo esc_attr($args['content'] . '-name');
                            ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label
                            for="<?php
                            echo esc_attr($args['content'] . '-id');
                            ?>">
                            <?php
                            echo esc_html(
                                __('Id attribute', 'pvb-cf7-calculator')
                            );
                            ?>
                        </label>
                    </th>
                    <td>
                        <input
                            type="text"
                            name="id"
                            class="idvalue oneline option"
                            id="<?php
                            echo esc_attr($args['content'] . '-id');
                            ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label
                            for="<?php
                            echo esc_attr($args['content'] . '-class');
                            ?>">
                            <?php
                            echo esc_html(
                                __('Class attribute', 'pvb-cf7-calculator')
                            );
                            ?>
                        </label>
                    </th>
                    <td>
                        <input
                            type="text"
                            name="class"
                            class="classvalue oneline option"
                            id="<?php
                            echo esc_attr($args['content'] . '-class');
                            ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php echo esc_html(__(
                            'Pay on submit',
                            'pvb-cf7-calculator'
                        )); ?>
                    </th>
                    <td>
                        <label><input
                            type="checkbox"
                            name="payonsubmit"
                            class="option"
                            value="on">
                            <?php
                            echo esc_html(__(
                                'Initiate payment automatically after ' .
                                    'submitting form',
                                'pvb-cf7-calculator'
                            ));
                            ?></label>
                    </td>
                </tr>                
                <tr>
                    <th scope="row">
                        <label for="<?php
                        echo esc_attr($args['content'] . '-values');
                        ?>">
                            <?php
                            echo esc_html(
                                __('Item name', 'pvb-cf7-calculator')
                            );
                            ?>
                        </label>
                    </th>
                    <td>
                        <input
                            type="text"
                            name="values"
                            class="oneline"
                            id="<?php
                            echo esc_attr($args['content'] . '-values');
                            ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php
                        echo esc_html(
                            __('Amount field name', 'pvb-cf7-calculator')
                        );
                        ?>
                    </th>
                    <td>
                        <input
                            type="text"
                            name="field"
                            class="fieldvalue oneline option"
                            id="<?php
                            echo esc_attr($args['content'] . '-field');
                            ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php
                        echo esc_html(
                            __('Currency code', 'pvb-cf7-calculator')
                        );
                        ?>
                    </th>
                    <td>
                        <input
                            type="text"
                            name="currency"
                            class="currencyvalue oneline option"
                            id="<?php
                            echo esc_attr($args['content'] . '-currency');
                            ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php
                        echo esc_html(
                            __('Client email field name', 'pvb-cf7-calculator')
                        );
                        ?>
                    </th>
                    <td>
                        <input
                            type="text"
                            name="emailfield"
                            class="emailfieldvalue oneline option"
                            id="<?php
                            echo esc_attr($args['content'] . '-emailfield');
                            ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php
                        echo esc_html(
                            __('Thank-you page slug', 'pvb-cf7-calculator')
                        );
                        ?>
                    </th>
                    <td>
                        <input
                            type="text"
                            name="success"
                            class="emailvalue oneline option"
                            id="<?php
                            echo esc_attr($args['content'] . '-success');
                            ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php
                        echo esc_html(
                            __(
                                'Payment Cancelled page slug',
                                'pvb-cf7-calculator'
                            )
                        );
                        ?>
                    </th>
                    <td>
                        <input
                            type="text"
                            name="fail"
                            class="emailvalue oneline option"
                            id="<?php
                            echo esc_attr($args['content'] . '-fail');
                            ?>" />
                    </td>
                </tr>
            </tbody>
        </table>
    </fieldset>
</div>

<div class="insert-box">
    <input
        type="text"
        name="<?php echo $type; ?>"
        class="tag code"
        readonly="readonly"
        onfocus="this.select()"
        />

    <div class="submitbox">
        <input
            type="button"
            class="button button-primary insert-tag"
            value="<?php
            echo esc_attr(__('Insert', 'pvb-cf7-calculator'));
            ?>" />
    </div>

    <br class="clear" />
</div>