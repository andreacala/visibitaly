<div class="control-box">
    <fieldset>
        <legend>
            <?php
            _e('Create a read-only form input that maps text values to numbers based on a spreadsheet.');
            echo ' ';
            printf(
                __('For more details, see %s'),
                '<a href="http://bossakov.eu/documentation/pvb-cf7-calculator-pro-' .
                    $pluginVersion .
                    '.pdf" target="_blank">' .
                    __('plugin documentation') .
                    '</a>'
            );
            ?>
        </legend>
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row">
                        <label for="<?php echo esc_attr($args['content'] . '-name'); ?>"><?php echo esc_html(__('Name', 'pvb-cf7-calculator')); ?></label>
                    </th>
                    <td>
                        <input type="text" name="name" class="tg-name oneline" id="<?php echo esc_attr($args['content'] . '-name'); ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="<?php echo esc_attr($args['content'] . '-id'); ?>"><?php echo esc_html(__('Id attribute', 'pvb-cf7-calculator')); ?></label>
                    </th>
                    <td>
                        <input type="text" name="id" class="idvalue oneline option" id="<?php echo esc_attr($args['content'] . '-id'); ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="<?php echo esc_attr($args['content'] . '-class'); ?>"><?php echo esc_html(__('Class attribute', 'pvb-cf7-calculator')); ?></label>
                    </th>
                    <td>
                        <input type="text" name="class" class="classvalue oneline option" id="<?php echo esc_attr($args['content'] . '-class'); ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php echo esc_html(__('Hide field', 'pvb-cf7-calculator')); ?>
                    </th>
                    <td>
                        <label><input type="checkbox" name="cf7-hide" class="option" value="on"> <?php echo esc_html(__('Hide field', 'pvb-cf7-calculator')); ?></label>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php echo esc_html(__('Text field to look up', 'pvb-cf7-calculator')); ?>
                    </th>
                    <td>
                        <input type="text" name="field" class="fieldvalue oneline option" id="<?php echo esc_attr($args['content'] . '-field'); ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php echo esc_html(__('Document path / URL', 'pvb-cf7-calculator')); ?>
                    </th>
                    <td>
                        <input type="text" name="values" class="documentvalue oneline" id="<?php echo esc_attr($args['content'] . '-values'); ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php echo esc_html(__('Sheet number', 'pvb-cf7-calculator')); ?>
                    </th>
                    <td>
                        <input type="text" name="sheet" class="sheetvalue oneline option" id="<?php echo esc_attr($args['content'] . '-sheet'); ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <?php echo esc_html(__('Cell range (e.g. A1-B10)', 'pvb-cf7-calculator')); ?>
                    </th>
                    <td>
                        <input type="text" name="cells" class="cellsvalue oneline option" id="<?php echo esc_attr($args['content'] . '-cells'); ?>" />
                    </td>
                </tr>
            </tbody>
        </table>
    </fieldset>
</div>

<div class="insert-box">
    <input type="text" name="<?php echo $type; ?>" class="tag code" readonly="readonly" onfocus="this.select()" />

    <div class="submitbox">
        <input type="button" class="button button-primary insert-tag" value="<?php echo esc_attr(__('Insert', 'pvb-cf7-calculator')); ?>" />
    </div>

    <br class="clear" />
</div>