<script type="application/javascript">
if (typeof stripeHandler == 'undefined') {
    var stripeHandler = null;
    var stripeName = '<?php
    echo addslashes(html_entity_decode(get_bloginfo("name"), ENT_QUOTES));
    ?>';
    jQuery.getScript(
        "https://checkout.stripe.com/checkout.js",
        function(data, textStatus, jqxhr) {
            stripeHandler = StripeCheckout.configure({
                key: '<?php echo addslashes($stripe_key); ?>',
                locale: 'auto',
                token: payWithStripe
            });

            // Close Checkout on page navigation
            window.addEventListener('popstate', function() {
              stripeHandler.close();
            });
        }
    );
}
</script>
<input
    type="button"
    class="pvb-stripe-button pvb-stripe-button-<?php
    echo esc_attr($field);
    ?> <?php echo esc_attr($extra_classes); ?>"
    data-field="<?php echo esc_attr($field); ?>"
    data-emailfield="<?php echo esc_attr($emailfield); ?>"
    data-item_name="<?php echo esc_attr($item_name); ?>"
    data-currency="<?php echo esc_attr($currency); ?>"
    data-zerodecimal="<?php echo esc_attr($zerodecimal); ?>"
    data-success_url="<?php echo esc_attr($success_url); ?>"
    data-fail_url="<?php echo esc_attr($fail_url); ?>"
    id="<?php echo esc_attr($id); ?>"
    style="display: none"
    <?php
    if ($payonsubmit) {
        echo 'data-payonsubmit="1"';
    }
    ?>
    value="Pay with Stripe">
