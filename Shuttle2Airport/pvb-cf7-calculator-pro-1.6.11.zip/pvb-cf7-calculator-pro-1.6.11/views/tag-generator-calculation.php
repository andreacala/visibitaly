<div class="control-box">
    <fieldset>
        <legend>
            <?php
            _e('Create a read-only form input with a value that\'s automatically calculated based on user input in another field.');
            echo ' ';
            printf(
                __('For more details, see %s'),
                '<a href="http://bossakov.eu/documentation/pvb-cf7-calculator-pro-' .
                    $pluginVersion .
                    '.pdf" target="_blank">' .
                    __('plugin documentation') .
                    '</a>'
            );
            ?></legend>
        <table class="form-table">
            <tbody>
                <tr>
                    <th scope="row">
                        <label for="<?php echo esc_attr($args['content'] . '-name'); ?>"><?php echo esc_html(__('Name', 'pvb-cf7-calculator')); ?></label>
                    </th>
                    <td>
                        <input type="text" name="name" class="tg-name oneline" id="<?php echo esc_attr($args['content'] . '-name'); ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="<?php echo esc_attr($args['content'] . '-id'); ?>"><?php echo esc_html(__('Id attribute', 'pvb-cf7-calculator')); ?></label>
                    </th>
                    <td>
                        <input type="text" name="id" class="idvalue oneline option" id="<?php echo esc_attr($args['content'] . '-id'); ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="<?php echo esc_attr($args['content'] . '-class'); ?>"><?php echo esc_html(__('Class attribute', 'pvb-cf7-calculator')); ?></label>
                    </th>
                    <td>
                        <input type="text" name="class" class="classvalue oneline option" id="<?php echo esc_attr($args['content'] . '-class'); ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="<?php echo esc_attr($args['content'] . '-init'); ?>"><?php echo esc_html(__('Initial value', 'pvb-cf7-calculator')); ?></label>
                    </th>
                    <td>
                        <input type="number" name="init" class="initvalue oneline option" id="<?php echo esc_attr($args['content'] . '-init'); ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="<?php echo esc_attr($args['content'] . '-min'); ?>"><?php echo esc_html(__('Minimum value', 'pvb-cf7-calculator')); ?></label>
                    </th>
                    <td>
                        <input type="number" name="min" class="minvalue oneline option" id="<?php echo esc_attr($args['content'] . '-min'); ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="<?php echo esc_attr($args['content'] . '-max'); ?>"><?php echo esc_html(__('Maximum value', 'pvb-cf7-calculator')); ?></label>
                    </th>
                    <td>
                        <input type="number" name="max" class="maxvalue oneline option" id="<?php echo esc_attr($args['content'] . '-max'); ?>" />
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="<?php echo esc_attr($args['content'] . '-precision'); ?>"><?php echo esc_html(__('Result precision (digits after decimal point)', 'pvb-cf7-calculator')); ?></label>
                    </th>
                    <td>
                        <input type="number" name="precision" class="precisionvalue oneline option" id="<?php echo esc_attr($args['content'] . '-precision'); ?>" />
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <?php echo esc_html(__(
                            'Result rounding',
                            'pvb-cf7-calculator'
                        )); ?>
                    </th>
                    <td>
                        <label><input
                            type="checkbox"
                            name="roundup"
                            id="roundup"
                            class="option"
                            value="on">
                        <?php echo esc_html(__(
                            'Always round up',
                            'pvb-cf7-calculator'
                        )); ?>
                        </label>
                    </td>
                </tr>                
                <tr>
                    <th scope="row">
                    </th>
                    <td>
                        <label><input
                            type="checkbox"
                            name="rounddown"
                            id="rounddown"
                            class="option"
                            value="on">
                        <?php echo esc_html(__(
                            'Always round down',
                            'pvb-cf7-calculator'
                        )); ?>
                        </label>
                    </td>
                </tr>                
                <tr>
                    <th scope="row">
                        <?php echo esc_html(__('Hide field', 'pvb-cf7-calculator')); ?>
                    </th>
                    <td>
                        <label><input type="checkbox" name="cf7-hide" class="option" value="on"> <?php echo esc_html(__('Hide field', 'pvb-cf7-calculator')); ?></label>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="<?php echo esc_attr($args['content'] . '-values'); ?>"><?php echo esc_html(__('Calculation formula', 'pvb-cf7-calculator')); ?></label>
                    </th>
                    <td>
                        <p class="cf7-container-tags">
                            <strong>
                                <?php
                                $tags = wpcf7_scan_form_tags();
                                foreach ($tags as $tag) {
                                    if (!empty($tag['name'])) {
                                        echo '[' . $tag['name'] . '] ';
                                    }
                                }
                                ?>
                            </strong>
                        </p>
                        <textarea rows="3" class="large-text code" name="values" id="<?php echo esc_attr($args['content'] . '-values'); ?>"></textarea><br>
                        <?php _e('Example: (field1 + field2) * 1.2', 'pvb-cf7-calculator'); ?><br>
                        </td>
                </tr>
            </tbody>
        </table>
    </fieldset>
</div>

<div class="insert-box">
    <input type="text" name="<?php echo $type; ?>" class="tag code" readonly="readonly" onfocus="this.select()" />

    <div class="submitbox">
        <input type="button" class="button button-primary insert-tag" value="<?php echo esc_attr(__('Insert', 'pvb-cf7-calculator')); ?>" />
    </div>

    <br class="clear" />
</div>

<script>
jQuery(document).ready(function($) {
    $('#roundup').click(function() {
        if ($(this).prop('checked')) {
            $('#rounddown').prop('checked', false);
        }
    });
    $('#rounddown').click(function() {
        if ($(this).prop('checked')) {
            $('#roundup').prop('checked', false);
        }
    });
});
</script>