<?php ob_start(); ?>
<form
    action="https://www.paypal.com/cgi-bin/webscr"
    method="post"
    id="pvb-paypal-form-<?php echo esc_attr($id); ?>"
    class="pvb-paypal-form"
    <?php
    if ($newtab) {
        echo 'target="_blank"';
    }
    ?>>

    <!-- Identify your business so that you can collect the payments. -->
    <input type="hidden" name="business" value="<?php echo esc_attr($email); ?>">

    <!-- Specify a Buy Now button. -->
    <input type="hidden" name="cmd" value="_xclick">

    <!-- Specify details about the item that buyers will purchase. -->
    <input
        type="hidden"
        name="item_name"
        value="<?php echo esc_attr($item_name); ?>">
    <input
        type="hidden"
        name="amount"
        id="pvb-paypal-amount-<?php echo esc_attr($id); ?>"
        data-field="<?php echo esc_attr($field); ?>"
        value="0.00"
        >
    <input type="hidden" name="currency_code" value="<?php
    echo esc_attr($currency);
    ?>">

    <?php if (!empty($return)) : ?>
        <input type="hidden" name="return" value="<?php
        echo esc_attr($return);
        ?>">
        <input type="hidden" name="rm" value="1">        
    <?php endif; ?>
    <?php if (!empty($cancel_return)) : ?>
        <input type="hidden" name="cancel_return" value="<?php
        echo esc_attr($cancel_return);
        ?>">        
    <?php endif; ?>
</form>

<?php
$html = ob_get_contents();
ob_end_clean();
?>
<script type="application/javascript">
jQuery('document').ready(function($) {
    if ($('#pvb-paypal-form-<?php echo esc_attr($id); ?>').length === 0) {
        var h = window.atob('<?php echo addslashes(base64_encode($html)) ;?>');
        $('body').append(h);
    }
});
</script>
<button
    type="button"
    class="pvb-paypal-button pvb-paypal-button-<?php echo esc_attr($field); ?> <?php echo esc_attr($extra_classes); ?>"
    data-field="<?php echo esc_attr($field); ?>"
    id="<?php echo esc_attr($id); ?>"
    style="display: none"
    <?php
    if ($payonsubmit) {
        echo 'data-payonsubmit="1"';
    }
    ?>>
    <img
        src="https://www.paypalobjects.com/webstatic/en_AU/i/buttons/btn_paywith_primary_m.png"
        alt="Pay with PayPal">
</button>
