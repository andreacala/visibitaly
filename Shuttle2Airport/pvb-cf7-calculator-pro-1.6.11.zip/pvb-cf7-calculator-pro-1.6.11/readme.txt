=== PVB Contact Form 7 Calculator Pro ===
Contributors: pbosakov
Tags: wordpress, cf7, contact form 7, calculator, price calculator, cost calculator, ideal weight calculator, calorie calculator, quote, booking calculator, car rental calculator, mortgage calculator, tax calculator, finance calculator, date calculator
Requires at least: 4.9.2
Tested up to: 5.0.3
Requires PHP: 5.6

Lets you easily turn any Contact Form 7 form into a quote or price estimate calculator.

== Description ==

#### Overview ####

With PVB Contact Form 7 Calculator, you can easily turn any Contact Form 7 form into a calculator. Calculated fields are based on user input and selections in other parts of the form. The plugin can be used for creating various types of calculators, such as an ideal weight calculator, calorie calculator, quote calculator for hotel booking, car rental quote calculator, mortgage calculator, tax calculator, finance calculators, date calculator, etc.

#### Features ####

* __Advanced calculations__ - set your custom formula based on user input, for example:
	`cost_per_day * days * (1 + (tax_percentage / 100))`
* __Hide calculated fields__ - they can be visible to the user or not. Your choice!
* __Server-side calculation__ - you don't have to disclose your top secret formula! Calculations are performed behind the scenes, on the server.
* __Calculate on button click__ - you can let your users trigger the calculations without submitting the form.
* __Calculate on submit__ - values are always calculated on submit, so you can use them in your notification emails.
* __Calculate on other events__ - you can also trigger calculations from another script at any time!
* __Correct floating-point math__ - PVB Contact Form 7 Calculator Pro handles decimal floating-point numbers properly, unlike many online calculators that introduce rounding errors when converting to binary and back, yielding incorrect results (such as 0.6 + 0.3 = 0.8999).
* __Multiple calculated fields__ _(Pro version only)_ - you can have as many as you like in the same form!
* __Intermediate calculation steps__ _(Pro version only)_ - calculated fields can be based on other calculated fields. They are evaluated in order, from top to bottom.
* __Assign numeric values to text fields__ _(Pro version only)_ - for example, you can assign a specific price to each choice in a drop-down menu.
* __Currency conversion__ _(Pro version only)_ - use up-to-date currency exchange rates in your formulas.
* __Accept payments__ _(Pro version only)_ - integration with PayPal and Stripe allows you to accept payments based on calculated amounts.
* __Custom PHP code__ _(Pro version only)_ - the calculator is not advanced enough for you? Now you can run any PHP code in your calculation formulas. For security reasons, this feature is disabled by default and you must explicitly enable it from the Options page.
* __Reference external spreadsheets__ _(Pro version only)_ - need to update your price list frequently? The calculator can look up data from an online spreadsheet in various formats (Google Sheets, Excel, CSV...)
* __Calculate travel distance and time__ _(Pro version only)_ - integration with Google Maps API allows you to work with addresses and locations.

#### Live demo ####

We have prepared a [Live Demo](http://bossakov.eu/wpdemo/pvb-cf7-calculator-pro/) to let you test the capabilities of PVB Contact Form 7 Calculator Pro.

#### Video tutorial ####

https://www.youtube.com/watch?v=1A2e60_DcZ4

== Installation ==

[Contact Form 7](https://wordpress.org/plugins/contact-form-7/) 5.0 or later is required.

1. Download the plugin zip file to your computer;
2. Unzip the file;
3. Upload the pvb-cf7-calculator-pro directory to your /wp-content/plugins/ directory.
4. Activate the plugin from the "Plugins" menu in WordPress.
5. Refer to the [plugin documentation](http://bossakov.eu/documentation/pvb-cf7-calculator-pro-1.6.8.pdf).
6. Review the plugin settings under the menu Contact / Calculator Settings.

== Frequently asked questions ==

= Can the plugin calculate values automatically, without having to press a button? =
Yes, there is an option for the calculate button that allows you to auto-trigger it whenever a form value is changed. Please refer to the [plugin documentation](http://bossakov.eu/documentation/pvb-cf7-calculator-pro-1.6.8.pdf) for more information.

= Can I use PVB Contact Form 7 Calculator Pro to accept payments on my website? =
Simple PayPal and Stripe integration is available. You can set up a "Pay Now" button that will appear automatically after calculating the total amount. Please refer to the [plugin documentation](http://bossakov.eu/documentation/pvb-cf7-calculator-pro-1.6.8.pdf) for more information.

= Can I use PVB Contact Form 7 Calculator Pro for currency conversion? =
Yes, you can! Please refer to the [plugin documentation](http://bossakov.eu/documentation/pvb-cf7-calculator-pro-1.6.8.pdf) to see an example of how to use the *fn_currency_convert* function.

= Can I use PVB Contact Form 7 Calculator Pro to calculate distance and travel time? =
Yes, this is available if you activate the Google Maps integration features. Please refer to the [plugin documentation](http://bossakov.eu/documentation/pvb-cf7-calculator-pro-1.6.8.pdf) for more information

= Can I reference a list of values in a spreadsheet when configuring my calculation formula? =
Yes, you can use values from an external spreadsheet that resides locally on the server, or elsewhere on the Internet. If you have a valid Google API key, you may also use values from Google Sheets. Please refer to the [plugin documentation](http://bossakov.eu/documentation/pvb-cf7-calculator-pro-1.6.8.pdf) for more information.

= I tried using some PHP code in my formula, but the calculator page now looks like a mess, why? =
One possible reason is that you have square brackets in your code. Since Contact Form 7 uses square brackets - "[" and "]" - to delimit form tags, square brackets in your PHP code will not be handled properly. If you need to access array elements, *please use curly braces*. In PHP, both square brackets and curly braces can be used interchangeably for accessing array elements (e.g. $array[42] and $array{42} will both do the same thing).

= How does the calculator handle multiple checkbox groups? =
If more than one checkbox is selected in the same group, the values will be summed. To avoid the possibility to select more than one checkbox at the same time, use the "exclusive" modifier in the checkbox tag, or use radio buttons instead. More information and examples are available in the [plugin documentation](http://bossakov.eu/documentation/pvb-cf7-calculator-pro-1.6.8.pdf).

== Changelog ==

= 1.6.11 =
* Fix: Stripe stuck in test mode
* Fix: PHP 5.6 compatibility issues

= 1.6.10 =
* Fix: incorrect handling of non-integer exponents

= 1.6.9 =
* Feature: added "initial value" option to calculation and variable fields
* Feature: values set to "Calculating..." while results are loading
* Feature: option to send customer email from a form field to Stripe when processing payments
* Feature: Google Places Autocomplete field now allows all types of locations, including businesses
* Feature: preserve field values after submitting form via AJAX
* Performance: trimmed codebase for faster download and setup

= 1.6.8 =
* Fix: parentheses in formula sometimes not parsed correctly when calculating distance

= 1.6.7 =
* Fix: avoid overriding any CF7 styles

= 1.6.6 =
* Fix: load Google Javascript over HTTPS

= 1.6.5 =
* Fix: "payonsubmit" not working with PayPal in some cases
* Fix: "cf7-hide" option not working correctly with some themes
* Fix: "roundup" and "rounddown" options not working correctly
* Feature: option to format numbers (e.g. group thousands) as you type

= 1.6.4 =
* Feature: checkbox and radio button groups from a spreadsheet
* Feature: automatically generate order ID field and pass it in the PayPal and Stripe item description

= 1.6.8 =
* Fix: spreadsheet_reference tag should ignore trailing spaces in spreadsheet cells
* Feature: number formatting with custom decimal and thousands separators
* Feature: number masking (enforce your chosen number format on input fields)
* Feature: auto-trigger option for the Calculate button
* Feature: hidden Calculate buttons

= 1.6.2 =
* Interface: added roundup and rounddown options to tag generator

= 1.6.1 =
* Fix: Parse error if short PHP opening tag is disabled

= 1.6.8 =
* Feature: Stripe payment button

= 1.5.1 =
* Fix: rounding to 0 decimal points not working
* Feature: auto-redirect to PayPal on form submit
* Feature: PayPal thank-you page
* Feature: option to open PayPal in new window
* Feature: option to choose if calculated values should be rounded up or down

= 1.5.0 =
* Feature: PayPal button

= 1.4.1 =
* Fix: groups of multiple checkboxes not supported

= 1.4.0 =
* Feature: address autocomplete (uses Google Maps API)
* Feature: travel distance calculation (uses Google Maps API)
* Feature: travel time calculation (uses Google Maps API)

= 1.3.0 =
* Feature: reference external spreadsheet to map text to numbers
* Feature: create a drop-down menu from an external spreadsheet

= 1.2.2 =
* Fix: trailing zeroes not displayed when precision parameter is set (e.g. 1.5 instead of 1.50)

= 1.2.1 =
* Fix: PHP code cannot access intermediate calculated values in $_POST array

= 1.2.0 =
* Feature: run PHP code

= 1.1.0 =
* Feature: currency conversion

= 1.0.0 =
* Initial release