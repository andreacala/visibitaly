<?php
/**
 * WordPress Settings Framework
 *
 * @author  Gilbert Pellegrom, James Kemp
 * @link    https://github.com/gilbitron/WordPress-Settings-Framework
 * @license MIT
 */

/**
 * Define your settings
 *
 * The first parameter of this filter should be wpsf_register_settings_[options_group],
 * in this case "pvb_cf7_calculator_settings_general".
 *
 * Your "options_group" is the second param you use when running new WordPressSettingsFramework()
 * from your init function. It's important as it differentiates your options from others.
 *
 * To use the tabbed example, simply change the second param in the filter below to 'wpsf_tabbed_settings'
 * and check out the tabbed settings function on line 156.
 */
add_filter('wpsf_register_settings_pvb_cf7_calculator_settings_general', 'pvb_cf7_calculator_tabless_settings');

/**
 * Tabless example
 */
function pvb_cf7_calculator_tabless_settings($wpsf_settings)
{
    // General Settings section
    $wpsf_settings[] = array(
        'section_id' => 'features',
        'section_title' => __('Features', 'pvb-cf7-calculator'),
        'section_description' => __('Here you can manage calculator features.', 'pvb-cf7-calculator'),
        'section_order' => 1, // The order of the section (required)
        'fields' => array(
            array(
                'id' => 'preserve_fields',
                'title' => __('Action after form submit', 'pvb-cf7-calculator'),
                'desc' => __(
                    'This option allows you to modify the default behavior ' .
                    'of Contact Form 7 after you submit a form.',
                    'pvb-cf7-calculator'
                ),
                'type' => 'radio',
                'choices' => array(
                    '0' => 'Reset form fields',
                    '1' => 'Preserve form fields'
                ),
                'default' => '0'
            ),
            array(
                'id' => 'decimal_separator',
                'title' => __('Decimal separator', 'pvb-cf7-calculator'),
                'type' => 'select',
                'choices' => array(
                    '.' => 'Dot: 1.23',
                    ',' => 'Comma 1,23'
                ),
                'default' => '.'
            ),
            array(
                'id' => 'thousands_separator',
                'title' => __('Thousands separator', 'pvb-cf7-calculator'),
                'type' => 'select',
                'choices' => array(
                    '' => 'None: 1000000',
                    ',' => 'Comma: 1,000,000',
                    ' ' => 'Space: 1 000 000',
                    '.' => 'Dot: 1.000.000'
                ),
                'default' => ''
            ),
            array(
                'id' => 'allow_eval',
                'title' => __('Allow PHP code in formulas', 'pvb-cf7-calculator'),
                'desc' => __(
                    'This option is a <strong>potential security risk</strong> and is disabled by default. ' .
                    'Enable it only if you are an experienced developer and know the risks involved!',
                    'pvb-cf7-calculator'
                ),
                'type' => 'radio',
                'choices' => array(
                    '0' => 'Off',
                    '1' => 'On'
                ),
                'default' => '0'
            ),
            array(
                'id' => 'allow_csv_local',
                'title' => __('Allow referencing locally stored spreadsheets in formulas', 'pvb-cf7-calculator'),
                'desc' => __('Get values from a spreadsheet stored on this web server. ' .
                    '<strong>Note:</strong> processing large spreadsheets may slow down your form ' .
                    'or cause Wordpress to run out of memory!', 'pvb-cf7-calculator'),
                'type' => 'radio',
                'choices' => array(
                    '0' => 'Off',
                    '1' => 'On'
                ),
                'default' => '0'
            ),
            array(
                'id' => 'allow_csv_remote',
                'title' => __('Allow referencing remote spreadsheets in formulas', 'pvb-cf7-calculator'),
                'desc' => __(
                    'Download CSV/Excel documents from a remote server ' .
                    'or get values from a Google Sheets spreadsheet. ' .
                    '<strong>Note:</strong> processing large spreadsheets may slow down your form ' .
                    'or cause Wordpress to run out of memory!',
                    'pvb-cf7-calculator'
                ),
                'type' => 'radio',
                'choices' => array(
                    '0' => 'Off',
                    '1' => 'On'
                ),
                'default' => '0'
            ),
            array(
                'id' => 'csv_remote_timeout',
                'title' => __('Timeout for downloading remote spreadsheets (seconds)', 'pvb-cf7-calculator'),
                'type' => 'number',
                'default' => '10'
            )
        )
    );

    $wpsf_settings[] = array(
        'section_id' => 'google',
        'section_title' => __('Google services', 'pvb-cf7-calculator'),
        'section_description' => __('Enter your Google API key here. This is required to access Google Sheets and Google Maps.
            Go to the <a href="https://console.developers.google.com/flows/enableapi?' .
            'apiid=sheets.googleapis.com&reusekey=true"
            target="_blank">Google API console</a> to generate or see your API keys.', 'pvb-cf7-calculator'),
        'section_order' => 2, // The order of the section (required)
        'fields' => array(
            array(
                'id' => 'google_api_key',
                'title' => 'Server-side Google API key',
                'desc' => 'An API key with access to the Sheets and/or Maps' .
                    ' API. Used for back-end access to APIs, can be' .
                    ' restricted by server IP address',
                'type' => 'text',
                'default' => ''
            ),
            array(
                'id' => 'google_api_key_client',
                'title' => 'Client-side Google API key',
                'desc' => 'An API key with access to the Sheets and/or Maps' .
                    ' API. Published on your web pages, can be restricted by' .
                    ' HTTP referer',
                'type' => 'text',
                'default' => ''
            )
        )
    );

    $wpsf_settings[] = array(
        'section_id' => 'stripe',
        'section_title' => __('Stripe', 'pvb-cf7-calculator'),
        'section_description' => __(
            'Enter your Stripe credentials here to enable Stripe payments. ' .
                'Your API keys are available on your <a href="' . 
                'https://dashboard.stripe.com/account/apikeys' .
                '" target="_blank">Stripe Dashboard</a>',
            'pvb-cf7-calculator'
        ),
        'section_order' => 3,
        'fields' => array(
            array(
                'id' => 'stripe_live',
                'title' => __('Stripe mode', 'pvb-cf7-calculator'),
                'type' => 'radio',
                'choices' => array(
                    '0' => 'Test',
                    '1' => 'Live'
                ),
                'default' => '0'
            ),
            array(
                'id' => 'stripe_publishable_key',
                'title' => 'Stripe Publishable Key (LIVE mode)',
                'desc' => '',
                'type' => 'text',
                'default' => ''
            ),
            array(
                'id' => 'stripe_secret_key',
                'title' => 'Stripe Secret Key (LIVE mode)',
                'desc' => '',
                'type' => 'text',
                'default' => ''
            ),
            array(
                'id' => 'stripe_publishable_key_test',
                'title' => 'Stripe Publishable Key (TEST mode)',
                'desc' => '',
                'type' => 'text',
                'default' => ''
            ),
            array(
                'id' => 'stripe_secret_key_test',
                'title' => 'Stripe Secret Key (TEST mode)',
                'desc' => '',
                'type' => 'text',
                'default' => ''
            )
        )
    );

    return $wpsf_settings;
}
