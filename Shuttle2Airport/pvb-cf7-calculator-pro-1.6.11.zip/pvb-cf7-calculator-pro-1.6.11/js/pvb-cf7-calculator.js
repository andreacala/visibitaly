function cf7Calculate($form) {
    // Retrieve form ID
    var form_id = null;
    var $form_div = $form.closest('div.wpcf7');
    if ($form_div.length == 0) {
        return;
    }
    var form_div_id = $form_div.attr('id');
    var matches = form_div_id.match(/wpcf7-f([0-9]+)/);
    if (matches !== null) {
        form_id = matches[1];
    }
    if (form_id === null) {
        return;
    }

    // Retrieve form values
    if (String($form[0].tagName).toLowerCase() !== 'form') {
        return;
    }

    var $button = $form_div.find('.cf7-calculate_button');
    if($button.length > 0) {
    	$button.prop('disabled', true);
    }

    var postdata = $form.serializeArray();

    // Add form ID to posted data
    postdata.push({name: 'action', value: 'pvb_calculate'});
    postdata.push({name: 'pvb_form_id', value: form_id});

    // Prepare PayPal buttons onclick event
    $form.find('.pvb-paypal-button').off('click').on('click', function() {
        if (parseFloat(jQuery(this).data('amount')) > 0) {
            var $pp_form = jQuery(
                '#pvb-paypal-form-' + jQuery(this).attr('id')
            );
            if ($pp_form.length > 0) {
                $pp_form.find(
                    'input[name=amount]'
                ).val(jQuery(this).data('amount'));
                
                var order_id = cf7GetOrderId($form);
                if (order_id != '') {
                    $item_name_input = $pp_form.find('input[name=item_name]');
                    if ($item_name_input
                        .val()
                        .toString()
                        .indexOf(order_id) == -1
                    ) {
                        $item_name_input.val(
                            $item_name_input.val() + ' - ' + order_id
                        );
                    }
                }
                
                $pp_form.submit();
            }
        }
    });

    // Prepare Stripe buttons onclick event
    $form.find('.pvb-stripe-button').off('click').on('click', function() {
        if (parseFloat(jQuery(this).data('amount')) > 0) {
            // Open Stripe Checkout
            stripeData.amount = parseFloat(jQuery(this).data('amount'));
            stripeData.currency = jQuery(this).data('currency');
            stripeData.item_name = jQuery(this).data('item_name');
            stripeData.zerodecimal = parseInt(jQuery(this).data('zerodecimal'));
            stripeData.success_url = jQuery(this).data('success_url');
            stripeData.fail_url = jQuery(this).data('fail_url');
            stripeData.form_id = jQuery(this).closest('div.wpcf7').attr('id');
            var stripeOptions = {
                name: stripeName,
                description: stripeData.item_name + ' - ' + cf7GetOrderId($form),
                amount: Math.round(
                    stripeData.amount * (
                        jQuery(this).data('zerodecimal') ? 1 : 100
                    )
                ),
                currency: stripeData.currency
            };
            if (jQuery(this).data('email')) {
                stripeOptions.email = jQuery(this).data('email');
            }
            stripeHandler.open(stripeOptions);
        }
    });

    // Set values to "Calculating..."
    jQuery('input.wpcf7-variable,input.wpcf7-calculation').val(
        pvbdata.msg_calculating
    );

    // Set emails on Stripe buttons
    var $stripeButtons = $form.find('.pvb-stripe-button');
    $stripeButtons.each(function() {
        var emailfield = jQuery(this).data('emailfield');
        if (emailfield) {
            jQuery(this).data(
                'email',
                $form.find('input[name=' + emailfield + ']').val()
            );
        }
    });

    // Send data to server
    jQuery.post(pvbdata.ajaxurl, postdata, function(r) {
        // Fill fields with results
        if (r instanceof Object) {

            var showIfManuallyClickable = function() {
                if(jQuery(this).data('payonsubmit')) {
                    // NOP
                } else {
                    jQuery(this).show();
                }
            };

            for (var name in r.formatted) {
                $form.find('input[name=' + name + ']').val(r.formatted[name]);

                // Are there any PayPal or Stripe buttons
                // associated with this field?
                var $btns = $form.find(
                    '.pvb-paypal-button-' + name + ',.pvb-stripe-button-' + name
                );
                $btns.data('amount', parseFloat(r.raw[name]).toFixed(2));
                if(parseFloat(r.raw[name]) > 0) {
                    $btns.each(showIfManuallyClickable);
                } else {
                    $btns.hide();
                }
            }
        }
        
        // Enable button again
        if ($button.length > 0) {
            $button.prop('disabled', false);
        }
        $form.trigger('wpcf7calculate');
    }).fail(function() {
        // Enable button again
        $button.prop('disabled', false);
        $form.trigger('wpcf7calculatefail');
    });
}

function cf7GetOrderId($form) {
    if ($form.find('.wpcf7-order-id').length > 0) {
        return $form.find('.wpcf7-order-id:first').val();
    } else {
        return '';
    }
}

function cf7CalculatorNumberFormat(number, decimals, dec_point, thousands_sep) {
  number = (number + '')
    .replace(/[^0-9+\-Ee.]/g, '');
  var n = !isFinite(+number) ? 0 : +number,
    prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
    sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
    dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
    s = '',
    toFixedFix = function(n, prec) {
      var k = Math.pow(10, prec);
      return '' + (Math.round(n * k) / k)
        .toFixed(prec);
    };
  // Fix for IE parseFloat(0.55).toFixed(0) = 0;
  s = (prec ? toFixedFix(n, prec) : '' + Math.round(n))
    .split('.');
  if (s[0].length > 3) {
    s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
  }
  if ((s[1] || '')
    .length < prec) {
    s[1] = s[1] || '';
    s[1] += new Array(prec - s[1].length + 1)
      .join('0');
  }
  return s.join(dec);
}

function cf7CalculatorCountDecimals(value) {

    var r = 0;
    var fValue = parseFloat(value);
    if (isNaN(fValue)) {
        return 0;
    }

    var trailingZeroes = 0;
    var re = /\..*?(0+)$/.exec(value);
    if (re !== null) {
        console.log(re);
        trailingZeroes = re[1].length;
    }

    if (Math.floor(fValue) !== fValue) {
        r = fValue.toString().split(".")[1].length || 0;
    } else {
        r = 0;
    }
    return r + trailingZeroes;
}

// Set proper decimal and thousands separators
function cf7CalculatorMask(number) {
    // Remove thousands separator
    if (pvbdata.thousands_separator == '.') {
        number = number.replace('.', '');        
    }

    // Convert decimal separator
    if (pvbdata.decimal_separator != '.') {
        number = number.replace(
            new RegExp(pvbdata.decimal_separator, 'g'), '.'
        );
    }

    // Remove any other non-numeric characters
    number = number.replace(/[^0-9\.]/g, '');

    // Add thousands separator
    r = cf7CalculatorNumberFormat(
        parseFloat(number),
        cf7CalculatorCountDecimals(number),
        pvbdata.decimal_separator,
        pvbdata.thousands_separator
    );

    if (number.match(/\.$/)) {
        r += pvbdata.decimal_separator;
    }
    return r;
}

// Input field masking
jQuery('.formatted-number').on('input', function() {
    jQuery(this).val(cf7CalculatorMask(jQuery(this).val()));
});

// Attach to Calculate buttons
jQuery('.cf7-calculate_button').click(function(event) {
    // Disable button
    var $button = jQuery(event.target);
    if ($button.length == 0) {
        return;
    }
    $button.prop('disabled', true);
    cf7Calculate($button.closest('form'));
});

jQuery('.cf7-calculate_button.autocalc').each(function() {
    var $form = jQuery(this).closest('form');
    if ($form.data('autocalc_attached')) {
        return;
    }
    var recalc = function() { 
        cf7Calculate($form);
    };
    $form.find('input[type=text],input[type=number],select').on(
        'change',
        recalc
    );
    $form.find('input[type=checkbox],input[type=radio]').on(
        'click',
        recalc
    );
    $form.data('autocalc_attached', true);
});

var cf7SendToPayPal = function(event) {
    var $btns = $form.find('.pvb-paypal-button');
    $btns.each(function() {
        var amt = jQuery(this).data('amount');
        if (parseFloat(jQuery(this).data('amount')) > 0) {
            jQuery(this).trigger('click');
        }
    });
};

var cf7SendToStripe = function(event) {
    var $btns = $form.find('.pvb-stripe-button');
    $btns.each(function() {
        var amt = jQuery(this).data('amount');
        if (parseFloat(jQuery(this).data('amount')) > 0) {
            jQuery(this).trigger('click');
        }
    });
};

var stripeData = {
    amount: 0,
    currency: 'USD',
    item_name: '',
    zerodecimal: 0,
    form_id: '',
    success_url: '',
    fail_url: '',
    order_id: ''
};
var payWithStripe = function(token) {
    var postdata = [
        {name: 'action', value: 'pvb_stripe_capture'},
        {name: 'token', value: token.id},
        {name: 'amount', value: stripeData.amount},
        {name: 'currency', value: stripeData.currency},
        {name: 'item_name', value: stripeData.item_name + ' - ' +
            cf7GetOrderId(jQuery('#' + stripeData.form_id)) },
        {name: 'zerodecimal', value: stripeData.zerodecimal}
    ];

    jQuery.post(pvbdata.ajaxurl, postdata, function(r) {
        if (jQuery('#stripe-result').length == 0) {
            jQuery('#' + stripeData.form_id + ' form').append(
                '<div id="stripe-result-' + stripeData.form_id +
                '" style="display: block;" role="alert"' +
                ' class="wpcf7-response-output"></div>'
            );
            var $result = jQuery('#stripe-result-' + stripeData.form_id);
            if (r.success) {
                $result.addClass('wpcf7-mail-sent-ok');
                $result.html('Payment successful');
                if (stripeData.success_url != '') {
                    window.location.href = stripeData.success_url;
                }
            } else {
                $result.removeClass('wpcf7-mail-sent-ok');
                $result.html('Payment failed');
                if (stripeData.fail_url != '') {
                    window.location.href = stripeData.fail_url;
                }
            }
        }
    });
};

// Attach to mailsent event
var wpcf7Elm = document.querySelector('.wpcf7');
if (wpcf7Elm) {
    wpcf7Elm.addEventListener('wpcf7mailsent', function(event) {
        var $formdiv = jQuery(event.target);
        $form = $formdiv.find('form.wpcf7-form:first');
        $form.find('.pvb-paypal-button').each(function() {
            if (jQuery(this).data('payonsubmit')) {
                // Calculate and do payment
                $form.off(
                    'wpcf7calculate',
                    cf7SendToPayPal
                ).on(
                    'wpcf7calculate',
                    cf7SendToPayPal);
                cf7Calculate($form);
                return;
            }
        });
        $form.find('.pvb-stripe-button').each(function() {
            if (jQuery(this).data('payonsubmit')) {
                // Calculate and do payment
                $form.off(
                    'wpcf7calculate',
                    cf7SendToStripe
                ).on(
                    'wpcf7calculate',
                    cf7SendToStripe);
                cf7Calculate($form);
                return;
            }
        });

        // Preserve fields?
        if (parseInt(pvbdata.preserve_fields) == 1) {
            var formdata = $form.serialize();
            var checkUnserialize = function() {
                if (!jQuery('.ajax-loader', $form).hasClass( 'is-active' )) {
                    // CF7 has submitted the form and cleared the fields
                    $form.unserialize(formdata);
                    cf7Calculate($form);
                } else {
                    // Check again after 100ms
                    setTimeout(checkUnserialize, 100);
                }
            };
            setTimeout(checkUnserialize, 100);
        }
    }, false);
}

jQuery.unserialize = function(str){
        var items = str.split('&');
        var ret = "{";
        var arrays = [];
        var index = "";
        for (var i = 0; i < items.length; i++) {
            var parts = items[i].split(/=/);
            //console.log(parts[0], parts[0].indexOf("%5B"),  parts[0].indexOf("["));
            if (parts[0].indexOf("%5B") > -1 || parts[0].indexOf("[") > -1){
                //Array serializado
                index = (parts[0].indexOf("%5B") > -1) ? parts[0].replace("%5B","").replace("%5D","") : parts[0].replace("[","").replace("]","");
                //console.log("array detectado:", index);
                //console.log(arrays[index] === undefined);
                if (arrays[index] === undefined){
                    arrays[index] = [];
                }
                arrays[index].push( decodeURIComponent(parts[1].replace(/\+/g," ")));
                //console.log("arrays:", arrays);
            } else {
                //console.log("common item (not array)");
                if (parts.length > 1){
                    ret += "\""+parts[0] + "\": \"" + decodeURIComponent(parts[1].replace(/\+/g," ")).replace(/\n/g,"\\n").replace(/\r/g,"\\r") + "\", ";
                }
            }
            
        }
        
        ret = (ret != "{") ? ret.substr(0,ret.length-2) + "}" : ret + "}";
        //console.log(ret, arrays);
        var ret2 = JSON.parse(ret);
        //proceso los arrays
        for (var arr in arrays){
            ret2[arr] = arrays[arr];
        }
        return ret2;
};

jQuery.fn.unserialize = function(parm){
        //If not string, JSON is assumed.
        var items = (typeof parm == "string") ? parm.split('&') : parm;
        if (typeof items !== "object"){
            throw new Error("unserialize: string or JSON object expected.");
        }
        //Check for the need of building an array from some item.
        //May return a false positive, but it's still better than looping twice.
        //TODO: confirm if it's ok to simplify this method by always calling
        //$.unserialize(parm) without any extra checking. 
        var need_to_build = ((typeof parm == "string") &&
            decodeURIComponent(parm).indexOf("[]=") > -1);
        items = (need_to_build) ? $.unserialize(parm) : items;
        
        
        for (var i in items){
            var parts = (items instanceof Array) ?
                items[i].split(/=/) :
                [i, (items[i] instanceof Array) ? items[i] : "" + items[i]];
            parts[0] = decodeURIComponent(parts[0]);
            if (parts[0].indexOf("[]") == -1 && parts[1] instanceof Array){
                parts[0] += "[]";
            }
            obj = this.find('[name=\''+ parts[0] +'\']');
            if (obj.length == 0){
                try{
                    obj = this.parent().find('[name=\''+ parts[0] +'\']');
                } catch(e){}
            }
            if (typeof obj.attr("type") == "string" &&
                (obj.attr("type").toLowerCase() == "radio" ||
                    obj.attr("type").toLowerCase() == "checkbox"
                )
            ) {
                 obj.each(function(index, coso) {
                    coso = jQuery(coso);
                    // if the value is an array, search the item with that value
                    var val;
                    if (parts[1] instanceof Array){
                        for (var i2 in parts[1]){
                            val = ""+parts[1][i2];
                            if (coso.attr("value") == decodeURIComponent(
                                val.replace(/\+/g," ")
                            )) {
                                coso.prop("checked",true);
                            } else {
                                if ($.inArray(coso.val(),parts[1]) < 0){
                                    coso.prop("checked",false);
                                }
                            }
                        }
                    } else {
                        val = "" + parts[1];
                        if (coso.attr("value") == decodeURIComponent(
                            val.replace(/\+/g," ")
                        )) {
                            coso.prop("checked",true);
                        } else {
                            coso.prop("checked",false);
                        }
                    }
                 });
            } else if (obj.length > 0 && obj[0].tagName == "SELECT" &&
                parts[1] instanceof Array && obj.prop("multiple")
            ) {
                //Here, i have an array for a multi-select.
                obj.val(parts[1]);
            } else {
                //When the value is an array, we join without delimiter
                var val = (parts[1] instanceof Array) ?
                    parts[1].join("") :
                    parts[1];
                //when the value is an object, we set the value to ""
                val = ((typeof val == "object") ||
                    (typeof val == "undefined")
                ) ? "" : val;
                
                obj.val(decodeURIComponent(val.replace(/\+/g," ")));
            }
        }
        return this;
};
