<?php
/*
Plugin Name:  PVB Contact Form 7 Calculator Pro
Plugin URI:   https://bossakov.eu/product/pvb-contact-form-7-calculator-pro/
Description:  Lets you easily turn any Contact Form 7 form into a quote or price estimate calculator.
Version:      1.6.11
Author:       Petko Bossakov
Author URI:   http://bossakov.eu/
License:      GPLv3 or later
Text Domain:  pvb-cf7-calculator
Domain Path:  /languages
*/

namespace PVBCF7CalculatorPro;

use PVBCF7CalculatorPro\lib\PVBCF7Calculator;

defined('ABSPATH') or die('No direct script access');
require_once dirname(__FILE__) . '/autoload.php';
require_once dirname(__FILE__) . '/lib/Google/vendor/autoload.php';
spl_autoload_register('PVBCF7CalculatorAutoload');
$PVBCF7CalculatorPro = new PVBCF7Calculator();
