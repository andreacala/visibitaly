<?php
namespace PVBCF7CalculatorPro\lib\Math;

interface TokenizerInterface
{
    /**
     * @param string $expression
     * @param array $functionNames
     * @return array Tokens of $expression
     */
    public function tokenize($expression, $functionNames = []);
}
