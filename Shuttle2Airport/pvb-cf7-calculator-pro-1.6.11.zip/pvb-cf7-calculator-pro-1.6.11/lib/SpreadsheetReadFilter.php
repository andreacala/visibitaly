<?php
namespace PVBCF7CalculatorPro\lib;

/**
 * Read filter helper -- read only certain cells when referencing a spreadsheet to conserve memory
 *
 * @since 1.3.0
 *
 */
class SpreadsheetReadFilter implements PhpSpreadsheet\Reader\IReadFilter
{
    private $cells  = [];
    private $range = '';

    /**
     * Class constructor
     *
     * @param array $cells
     * @since 1.3.0
     *
     */
    public function __construct($cells)
    {
        if (is_array($cells)) {
            $this->cells = $cells;
        } elseif (is_string($cells)) {
            $this->range = $cells;
        }
    }

    /**
     * Determine if a specific cell should be read or not
     *
     * @param string $column
     * @param int $row
     * @param string $worksheetName
     * @return bool
     * @since 1.3.0
     *
     */
    public function readCell($column, $row, $worksheetName = '')
    {
        if (!empty($this->cells)) {
            return $this->validateCellArray($column, $row, $worksheetName);
        } elseif (!empty($this->range)) {
            return $this->validateRange($column, $row, $worksheetName);
        } else {
            return true;
        }
    }

    /**
     * Determine if a specific cell is in the allowed list of cells
     *
     * @param string $column
     * @param int $row
     * @param string $worksheetName
     * @return bool
     * @since 1.3.0
     *
     */
    private function validateCellArray($column, $row, $worksheetName = '')
    {
        //  Only read the rows and columns that were configured
        $cellCoordinates = array(PhpSpreadsheet\Cell\Coordinate::columnIndexFromString($column), $row);
        foreach ($this->cells as $cell) {
            if ($cell[0] = $cellCoordinates[0] && $cell[1] = $cellCoordinates[1]) {
                return true;
            }
        }
        return false;
    }

    /**
     * Determine if a specific cell is in the allowed range
     *
     * @param string $column
     * @param int $row
     * @param string $worksheetName
     * @return bool
     * @since 1.3.0
     *
     */
    public function validateRange($column, $row, $worksheetName = '')
    {
        //  Only read the rows and columns that were configured
        list($rangeStart, $rangeEnd) = PhpSpreadsheet\Cell\Coordinate::rangeBoundaries($this->range);

        // Translate properties
        $myColumn = PhpSpreadsheet\Cell\Coordinate::columnIndexFromString($column);
        $myRow = $row;

        // Verify if cell is in range
        return ($rangeStart[0] <= $myColumn) && ($rangeEnd[0] >= $myColumn) &&
                ($rangeStart[1] <= $myRow) && ($rangeEnd[1] >= $myRow);
    }
}
