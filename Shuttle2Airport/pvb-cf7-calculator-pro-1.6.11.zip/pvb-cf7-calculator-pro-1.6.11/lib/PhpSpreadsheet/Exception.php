<?php

namespace PVBCF7CalculatorPro\lib\PhpSpreadsheet;

class Exception extends \Exception
{
}
