<?php

namespace PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer;

use PVBCF7CalculatorPro\lib\PhpSpreadsheet\Exception as PhpSpreadsheetException;

class Exception extends PhpSpreadsheetException
{
}
