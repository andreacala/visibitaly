<?php

namespace PVBCF7CalculatorPro\lib\PhpSpreadsheet\Helper;

class Migrator
{
    /**
     * Return the ordered mapping from old PHPExcel class names to new PhpSpreadsheet one.
     *
     * @return string[]
     */
    public function getMapping()
    {
        // Order matters here, we should have the deepest namespaces first (the most "unique" strings)
        $classes = [
            'PHPExcel_Shared_Escher_DggContainer_BstoreContainer_BSE_Blip' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\Escher\DggContainer\BstoreContainer\BSE\Blip::class,
            'PHPExcel_Shared_Escher_DgContainer_SpgrContainer_SpContainer' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\Escher\DgContainer\SpgrContainer\SpContainer::class,
            'PHPExcel_Shared_Escher_DggContainer_BstoreContainer_BSE' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\Escher\DggContainer\BstoreContainer\BSE::class,
            'PHPExcel_Shared_Escher_DgContainer_SpgrContainer' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\Escher\DgContainer\SpgrContainer::class,
            'PHPExcel_Shared_Escher_DggContainer_BstoreContainer' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\Escher\DggContainer\BstoreContainer::class,
            'PHPExcel_Shared_OLE_PPS_File' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\OLE\PPS\File::class,
            'PHPExcel_Shared_OLE_PPS_Root' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\OLE\PPS\Root::class,
            'PHPExcel_Worksheet_AutoFilter_Column_Rule' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Worksheet\AutoFilter\Column\Rule::class,
            'PHPExcel_Writer_OpenDocument_Cell_Comment' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Ods\Cell\Comment::class,
            'PHPExcel_Calculation_Token_Stack' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Calculation\Token\Stack::class,
            'PHPExcel_Chart_Renderer_jpgraph' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Chart\Renderer\JpGraph::class,
            'PHPExcel_Reader_Excel5_Escher' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Reader\Xls\Escher::class,
            'PHPExcel_Reader_Excel5_MD5' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Reader\Xls\MD5::class,
            'PHPExcel_Reader_Excel5_RC4' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Reader\Xls\RC4::class,
            'PHPExcel_Reader_Excel2007_Chart' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Reader\Xlsx\Chart::class,
            'PHPExcel_Reader_Excel2007_Theme' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Reader\Xlsx\Theme::class,
            'PHPExcel_Shared_Escher_DgContainer' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\Escher\DgContainer::class,
            'PHPExcel_Shared_Escher_DggContainer' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\Escher\DggContainer::class,
            'CholeskyDecomposition' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\JAMA\CholeskyDecomposition::class,
            'EigenvalueDecomposition' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\JAMA\EigenvalueDecomposition::class,
            'PHPExcel_Shared_JAMA_LUDecomposition' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\JAMA\LUDecomposition::class,
            'PHPExcel_Shared_JAMA_Matrix' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\JAMA\Matrix::class,
            'QRDecomposition' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\JAMA\QRDecomposition::class,
            'PHPExcel_Shared_JAMA_QRDecomposition' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\JAMA\QRDecomposition::class,
            'SingularValueDecomposition' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\JAMA\SingularValueDecomposition::class,
            'PHPExcel_Shared_OLE_ChainedBlockStream' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\OLE\ChainedBlockStream::class,
            'PHPExcel_Shared_OLE_PPS' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\OLE\PPS::class,
            'PHPExcel_Best_Fit' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\Trend\BestFit::class,
            'PHPExcel_Exponential_Best_Fit' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\Trend\ExponentialBestFit::class,
            'PHPExcel_Linear_Best_Fit' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\Trend\LinearBestFit::class,
            'PHPExcel_Logarithmic_Best_Fit' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\Trend\LogarithmicBestFit::class,
            'polynomialBestFit' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\Trend\PolynomialBestFit::class,
            'PHPExcel_Polynomial_Best_Fit' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\Trend\PolynomialBestFit::class,
            'powerBestFit' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\Trend\PowerBestFit::class,
            'PHPExcel_Power_Best_Fit' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\Trend\PowerBestFit::class,
            'trendClass' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\Trend\Trend::class,
            'PHPExcel_Worksheet_AutoFilter_Column' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Worksheet\AutoFilter\Column::class,
            'PHPExcel_Worksheet_Drawing_Shadow' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Worksheet\Drawing\Shadow::class,
            'PHPExcel_Writer_OpenDocument_Content' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Ods\Content::class,
            'PHPExcel_Writer_OpenDocument_Meta' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Ods\Meta::class,
            'PHPExcel_Writer_OpenDocument_MetaInf' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Ods\MetaInf::class,
            'PHPExcel_Writer_OpenDocument_Mimetype' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Ods\Mimetype::class,
            'PHPExcel_Writer_OpenDocument_Settings' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Ods\Settings::class,
            'PHPExcel_Writer_OpenDocument_Styles' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Ods\Styles::class,
            'PHPExcel_Writer_OpenDocument_Thumbnails' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Ods\Thumbnails::class,
            'PHPExcel_Writer_OpenDocument_WriterPart' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Ods\WriterPart::class,
            'PHPExcel_Writer_PDF_Core' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Pdf::class,
            'PHPExcel_Writer_PDF_DomPDF' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Pdf\Dompdf::class,
            'PHPExcel_Writer_PDF_mPDF' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Pdf\Mpdf::class,
            'PHPExcel_Writer_PDF_tcPDF' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Pdf\Tcpdf::class,
            'PHPExcel_Writer_Excel5_BIFFwriter' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Xls\BIFFwriter::class,
            'PHPExcel_Writer_Excel5_Escher' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Xls\Escher::class,
            'PHPExcel_Writer_Excel5_Font' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Xls\Font::class,
            'PHPExcel_Writer_Excel5_Parser' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Xls\Parser::class,
            'PHPExcel_Writer_Excel5_Workbook' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Xls\Workbook::class,
            'PHPExcel_Writer_Excel5_Worksheet' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Xls\Worksheet::class,
            'PHPExcel_Writer_Excel5_Xf' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Xls\Xf::class,
            'PHPExcel_Writer_Excel2007_Chart' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Xlsx\Chart::class,
            'PHPExcel_Writer_Excel2007_Comments' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Xlsx\Comments::class,
            'PHPExcel_Writer_Excel2007_ContentTypes' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Xlsx\ContentTypes::class,
            'PHPExcel_Writer_Excel2007_DocProps' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Xlsx\DocProps::class,
            'PHPExcel_Writer_Excel2007_Drawing' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Xlsx\Drawing::class,
            'PHPExcel_Writer_Excel2007_Rels' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Xlsx\Rels::class,
            'PHPExcel_Writer_Excel2007_RelsRibbon' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Xlsx\RelsRibbon::class,
            'PHPExcel_Writer_Excel2007_RelsVBA' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Xlsx\RelsVBA::class,
            'PHPExcel_Writer_Excel2007_StringTable' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Xlsx\StringTable::class,
            'PHPExcel_Writer_Excel2007_Style' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Xlsx\Style::class,
            'PHPExcel_Writer_Excel2007_Theme' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Xlsx\Theme::class,
            'PHPExcel_Writer_Excel2007_Workbook' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Xlsx\Workbook::class,
            'PHPExcel_Writer_Excel2007_Worksheet' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Xlsx\Worksheet::class,
            'PHPExcel_Writer_Excel2007_WriterPart' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Xlsx\WriterPart::class,
            'PHPExcel_CachedObjectStorage_CacheBase' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Collection\Cells::class,
            'PHPExcel_CalcEngine_CyclicReferenceStack' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Calculation\Engine\CyclicReferenceStack::class,
            'PHPExcel_CalcEngine_Logger' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Calculation\Engine\Logger::class,
            'PHPExcel_Calculation_Functions' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Calculation\Functions::class,
            'PHPExcel_Calculation_Function' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Calculation\Category::class,
            'PHPExcel_Calculation_Database' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Calculation\Database::class,
            'PHPExcel_Calculation_DateTime' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Calculation\DateTime::class,
            'PHPExcel_Calculation_Engineering' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Calculation\Engineering::class,
            'PHPExcel_Calculation_Exception' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Calculation\Exception::class,
            'PHPExcel_Calculation_ExceptionHandler' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Calculation\ExceptionHandler::class,
            'PHPExcel_Calculation_Financial' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Calculation\Financial::class,
            'PHPExcel_Calculation_FormulaParser' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Calculation\FormulaParser::class,
            'PHPExcel_Calculation_FormulaToken' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Calculation\FormulaToken::class,
            'PHPExcel_Calculation_Logical' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Calculation\Logical::class,
            'PHPExcel_Calculation_LookupRef' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Calculation\LookupRef::class,
            'PHPExcel_Calculation_MathTrig' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Calculation\MathTrig::class,
            'PHPExcel_Calculation_Statistical' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Calculation\Statistical::class,
            'PHPExcel_Calculation_TextData' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Calculation\TextData::class,
            'PHPExcel_Cell_AdvancedValueBinder' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Cell\AdvancedValueBinder::class,
            'PHPExcel_Cell_DataType' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Cell\DataType::class,
            'PHPExcel_Cell_DataValidation' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Cell\DataValidation::class,
            'PHPExcel_Cell_DefaultValueBinder' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Cell\DefaultValueBinder::class,
            'PHPExcel_Cell_Hyperlink' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Cell\Hyperlink::class,
            'PHPExcel_Cell_IValueBinder' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Cell\IValueBinder::class,
            'PHPExcel_Chart_Axis' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Chart\Axis::class,
            'PHPExcel_Chart_DataSeries' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Chart\DataSeries::class,
            'PHPExcel_Chart_DataSeriesValues' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Chart\DataSeriesValues::class,
            'PHPExcel_Chart_Exception' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Chart\Exception::class,
            'PHPExcel_Chart_GridLines' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Chart\GridLines::class,
            'PHPExcel_Chart_Layout' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Chart\Layout::class,
            'PHPExcel_Chart_Legend' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Chart\Legend::class,
            'PHPExcel_Chart_PlotArea' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Chart\PlotArea::class,
            'PHPExcel_Properties' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Chart\Properties::class,
            'PHPExcel_Chart_Title' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Chart\Title::class,
            'PHPExcel_DocumentProperties' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Document\Properties::class,
            'PHPExcel_DocumentSecurity' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Document\Security::class,
            'PHPExcel_Helper_HTML' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Helper\Html::class,
            'PHPExcel_Reader_Abstract' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Reader\BaseReader::class,
            'PHPExcel_Reader_CSV' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Reader\Csv::class,
            'PHPExcel_Reader_DefaultReadFilter' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Reader\DefaultReadFilter::class,
            'PHPExcel_Reader_Excel2003XML' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Reader\Xml::class,
            'PHPExcel_Reader_Exception' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Reader\Exception::class,
            'PHPExcel_Reader_Gnumeric' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Reader\Gnumeric::class,
            'PHPExcel_Reader_HTML' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Reader\Html::class,
            'PHPExcel_Reader_IReadFilter' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Reader\IReadFilter::class,
            'PHPExcel_Reader_IReader' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Reader\IReader::class,
            'PHPExcel_Reader_OOCalc' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Reader\Ods::class,
            'PHPExcel_Reader_SYLK' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Reader\Slk::class,
            'PHPExcel_Reader_Excel5' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Reader\Xls::class,
            'PHPExcel_Reader_Excel2007' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Reader\Xlsx::class,
            'PHPExcel_RichText_ITextElement' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\RichText\ITextElement::class,
            'PHPExcel_RichText_Run' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\RichText\Run::class,
            'PHPExcel_RichText_TextElement' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\RichText\TextElement::class,
            'PHPExcel_Shared_CodePage' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\CodePage::class,
            'PHPExcel_Shared_Date' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\Date::class,
            'PHPExcel_Shared_Drawing' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\Drawing::class,
            'PHPExcel_Shared_Escher' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\Escher::class,
            'PHPExcel_Shared_File' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\File::class,
            'PHPExcel_Shared_Font' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\Font::class,
            'PHPExcel_Shared_OLE' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\OLE::class,
            'PHPExcel_Shared_OLERead' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\OLERead::class,
            'PHPExcel_Shared_PasswordHasher' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\PasswordHasher::class,
            'PHPExcel_Shared_String' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\StringHelper::class,
            'PHPExcel_Shared_TimeZone' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\TimeZone::class,
            'PHPExcel_Shared_XMLWriter' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\XMLWriter::class,
            'PHPExcel_Shared_Excel5' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Shared\Xls::class,
            'PHPExcel_Style_Alignment' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Style\Alignment::class,
            'PHPExcel_Style_Border' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Style\Border::class,
            'PHPExcel_Style_Borders' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Style\Borders::class,
            'PHPExcel_Style_Color' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Style\Color::class,
            'PHPExcel_Style_Conditional' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Style\Conditional::class,
            'PHPExcel_Style_Fill' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Style\Fill::class,
            'PHPExcel_Style_Font' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Style\Font::class,
            'PHPExcel_Style_NumberFormat' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Style\NumberFormat::class,
            'PHPExcel_Style_Protection' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Style\Protection::class,
            'PHPExcel_Style_Supervisor' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Style\Supervisor::class,
            'PHPExcel_Worksheet_AutoFilter' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Worksheet\AutoFilter::class,
            'PHPExcel_Worksheet_BaseDrawing' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Worksheet\BaseDrawing::class,
            'PHPExcel_Worksheet_CellIterator' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Worksheet\CellIterator::class,
            'PHPExcel_Worksheet_Column' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Worksheet\Column::class,
            'PHPExcel_Worksheet_ColumnCellIterator' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Worksheet\ColumnCellIterator::class,
            'PHPExcel_Worksheet_ColumnDimension' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Worksheet\ColumnDimension::class,
            'PHPExcel_Worksheet_ColumnIterator' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Worksheet\ColumnIterator::class,
            'PHPExcel_Worksheet_Drawing' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Worksheet\Drawing::class,
            'PHPExcel_Worksheet_HeaderFooter' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Worksheet\HeaderFooter::class,
            'PHPExcel_Worksheet_HeaderFooterDrawing' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Worksheet\HeaderFooterDrawing::class,
            'PHPExcel_WorksheetIterator' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Worksheet\Iterator::class,
            'PHPExcel_Worksheet_MemoryDrawing' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Worksheet\MemoryDrawing::class,
            'PHPExcel_Worksheet_PageMargins' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Worksheet\PageMargins::class,
            'PHPExcel_Worksheet_PageSetup' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Worksheet\PageSetup::class,
            'PHPExcel_Worksheet_Protection' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Worksheet\Protection::class,
            'PHPExcel_Worksheet_Row' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Worksheet\Row::class,
            'PHPExcel_Worksheet_RowCellIterator' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Worksheet\RowCellIterator::class,
            'PHPExcel_Worksheet_RowDimension' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Worksheet\RowDimension::class,
            'PHPExcel_Worksheet_RowIterator' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Worksheet\RowIterator::class,
            'PHPExcel_Worksheet_SheetView' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Worksheet\SheetView::class,
            'PHPExcel_Writer_Abstract' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\BaseWriter::class,
            'PHPExcel_Writer_CSV' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Csv::class,
            'PHPExcel_Writer_Exception' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Exception::class,
            'PHPExcel_Writer_HTML' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Html::class,
            'PHPExcel_Writer_IWriter' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\IWriter::class,
            'PHPExcel_Writer_OpenDocument' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Ods::class,
            'PHPExcel_Writer_PDF' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Pdf::class,
            'PHPExcel_Writer_Excel5' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Xls::class,
            'PHPExcel_Writer_Excel2007' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Writer\Xlsx::class,
            'PHPExcel_CachedObjectStorageFactory' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Collection\CellsFactory::class,
            'PHPExcel_Calculation' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Calculation\Calculation::class,
            'PHPExcel_Cell' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Cell\Cell::class,
            'PHPExcel_Chart' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Chart\Chart::class,
            'PHPExcel_Comment' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Comment::class,
            'PHPExcel_Exception' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Exception::class,
            'PHPExcel_HashTable' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\HashTable::class,
            'PHPExcel_IComparable' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\IComparable::class,
            'PHPExcel_IOFactory' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\IOFactory::class,
            'PHPExcel_NamedRange' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\NamedRange::class,
            'PHPExcel_ReferenceHelper' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\ReferenceHelper::class,
            'PHPExcel_RichText' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\RichText\RichText::class,
            'PHPExcel_Settings' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Settings::class,
            'PHPExcel_Style' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Style\Style::class,
            'PHPExcel_Worksheet' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Worksheet\Worksheet::class,
            'PHPExcel' => \PVBCF7CalculatorPro\lib\PhpSpreadsheet\Spreadsheet::class,
        ];

        $methods = [
            'MINUTEOFHOUR' => 'MINUTE',
            'SECONDOFMINUTE' => 'SECOND',
            'DAYOFWEEK' => 'WEEKDAY',
            'WEEKOFYEAR' => 'WEEKNUM',
            'ExcelToPHPObject' => 'excelToDateTimeObject',
            'ExcelToPHP' => 'excelToTimestamp',
            'FormattedPHPToExcel' => 'formattedPHPToExcel',
            'Cell::absoluteCoordinate' => 'Coordinate::absoluteCoordinate',
            'Cell::absoluteReference' => 'Coordinate::absoluteReference',
            'Cell::buildRange' => 'Coordinate::buildRange',
            'Cell::columnIndexFromString' => 'Coordinate::columnIndexFromString',
            'Cell::coordinateFromString' => 'Coordinate::coordinateFromString',
            'Cell::extractAllCellReferencesInRange' => 'Coordinate::extractAllCellReferencesInRange',
            'Cell::getRangeBoundaries' => 'Coordinate::getRangeBoundaries',
            'Cell::mergeRangesInCollection' => 'Coordinate::mergeRangesInCollection',
            'Cell::rangeBoundaries' => 'Coordinate::rangeBoundaries',
            'Cell::rangeDimension' => 'Coordinate::rangeDimension',
            'Cell::splitRange' => 'Coordinate::splitRange',
            'Cell::stringFromColumnIndex' => 'Coordinate::stringFromColumnIndex',
        ];

        // Keep '\' prefix for class names
        $prefixedClasses = [];
        foreach ($classes as $key => &$value) {
            $value = str_replace('PhpOffice\\', '\\PhpOffice\\', $value);
            $prefixedClasses['\\' . $key] = $value;
        }
        $mapping = $prefixedClasses + $classes + $methods;

        return $mapping;
    }

    /**
     * Search in all files in given directory.
     *
     * @param string $path
     */
    private function recursiveReplace($path)
    {
        $patterns = [
            '/*.md',
            '/*.php',
            '/*.phtml',
            '/*.txt',
            '/*.TXT',
        ];

        $from = array_keys($this->getMapping());
        $to = array_values($this->getMapping());

        foreach ($patterns as $pattern) {
            foreach (glob($path . $pattern) as $file) {
                $original = file_get_contents($file);
                $converted = str_replace($from, $to, $original);

                if ($original !== $converted) {
                    echo $file . " converted\n";
                    file_put_contents($file, $converted);
                }
            }
        }

        // Do the recursion in subdirectory
        foreach (glob($path . '/*', GLOB_ONLYDIR) as $subpath) {
            if (strpos($subpath, $path . '/') === 0) {
                $this->recursiveReplace($subpath);
            }
        }
    }

    public function migrate()
    {
        $path = realpath(getcwd());
        echo 'This will search and replace recursively in ' . $path . PHP_EOL;
        echo 'You MUST backup your files first, or you risk losing data.' . PHP_EOL;
        echo 'Are you sure ? (y/n)';

        $confirm = fread(STDIN, 1);
        if ($confirm === 'y') {
            $this->recursiveReplace($path);
        }
    }
}
