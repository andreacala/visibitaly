<?php

namespace PVBCF7CalculatorPro\lib\PhpSpreadsheet\Chart;

use PVBCF7CalculatorPro\lib\PhpSpreadsheet\Exception as PhpSpreadsheetException;

class Exception extends PhpSpreadsheetException
{
}
