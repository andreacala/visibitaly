<?php

namespace PVBCF7CalculatorPro\lib\PhpSpreadsheet\Cell;

interface IValueBinder
{
    /**
     * Bind value to a cell.
     *
     * @param Cell $cell Cell to bind value to
     * @param mixed $value Value to bind in cell
     *
     * @return bool
     */
    public function bindValue(Cell $cell, $value);
}
