<?php

namespace PVBCF7CalculatorPro\lib\PhpSpreadsheet;

interface IComparable
{
    /**
     * Get hash code.
     *
     * @return string Hash code
     */
    public function getHashCode();
}
