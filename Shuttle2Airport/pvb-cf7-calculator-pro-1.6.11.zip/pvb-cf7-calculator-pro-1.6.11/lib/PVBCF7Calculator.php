<?php
namespace PVBCF7CalculatorPro\lib;

use \WPCF7_ContactForm;
use \WPCF7_FormTag;
use \WPCF7_TagGenerator;
use PVBCF7CalculatorPro\lib\Math\PVBCalculator;
use PVBCF7CalculatorPro\lib\wpSettingsFramework;
use PVBCF7CalculatorPro\lib\wpSettingsFramework\WordPressSettingsFramework;
use PVBCF7CalculatorPro\lib\PhpSpreadsheet;

define('PVB_CF7_CALCULATOR_PRO_PATH', dirname(dirname(__FILE__)));

class PVBCF7Calculator
{

    /**
     * Minimum Contact Form 7 version required
     */
    const CF7_VERSION_REQUIRED = '5.0';

    /**
     * Output extra debugging info
     */
    const DEBUG = false;

    /**
     * Unique ID string for plugin settings page
     */
    const SETTINGS_PAGE = 'pvb_cf7_calculator_settings_general';

    /**
     * @var string[]
     * @since 1.3.0
     */
    private $downloaded_files = array();

    /**
     * @var string This plugin's current version
     */
    private $pluginVersion;

    /**
     * @var WordPressSettingsFramework
     */
    private $wpsf;

    /**
     * Class constructor
     *
     * @since 1.0.0
     *
     */
    public function __construct()
    {
        if (self::DEBUG) {
            error_reporting(E_ALL);
            ini_set('display_errors', 1);
        }

        add_action('init', array($this, 'init'));
        add_action('wpcf7_init', array($this,'cf7Init'), 20);
        add_action('wpcf7_admin_init', array($this, 'adminInit'), 60);
        add_action('admin_menu', array($this, 'settingsMenu'));

        // Set plugin version
        $plugin_data = get_file_data(
            PVB_CF7_CALCULATOR_PRO_PATH . '/pvb-cf7-calculator.php',
            array('Version' => 'Version'),
            false
        );
        $this->pluginVersion = $plugin_data['Version'];

        // Register settings
        $this->wpsf = new WordPressSettingsFramework(
            PVB_CF7_CALCULATOR_PRO_PATH . '/settings/settings-general.php',
            self::SETTINGS_PAGE
        );
    }

    /**
     * Display a dialog to generate a map input in the form
     *
     * @param WPCF7_ContactForm $contact_form
     * @param array $options
     * @since 1.4.0
     *
     */
    public function addressTagGenerator($contact_form, $options)
    {
        $data = array(
            'args' => wp_parse_args($options, array()),
            'type' => 'address'
        );
        $this->loadView('tag-generator-address', $data);
    }

    /**
     * Process address input tags
     *
     * @param WPCF7_FormTag $tag
     * @return string
     * @since 1.4.0
     *
     */
    public function addressTagHandler($tag)
    {
        $api_key_client = wpSettingsFramework\wpsf_get_setting(
            self::SETTINGS_PAGE,
            'google',
            'google_api_key_client'
        );

        // For backward compatibility
        if (empty($api_key_client)) {
            $api_key_client = wpSettingsFramework\wpsf_get_setting(
                self::SETTINGS_PAGE,
                'google',
                'google_api_key'
            );
        }
        wp_enqueue_script(
            'googleplaces',
            'https://maps.googleapis.com/maps/api/js?libraries=places&key=' .
                $api_key_client,
            array(),
            $this->pluginVersion,
            true
        );
        wp_enqueue_script(
            'geocomplete',
            plugins_url('js/jquery.geocomplete.min.js', dirname(__FILE__)),
            array('jquery', 'googleplaces'),
            $this->pluginVersion,
            true
        );

        if (empty($tag->name)) {
            return '';
        }

        $validation_error = wpcf7_get_validation_error($tag->name);
        $class = wpcf7_form_controls_class($tag->type, 'wpcf7-text');
        if ($validation_error) {
            $class .= ' wpcf7-not-valid';
        }

        $atts = array();

        $atts['size'] = $tag->get_size_option('40');
        $atts['class'] = $tag->get_class_option($class);
        $atts['id'] = $tag->get_id_option();
        $atts['tabindex'] = $tag->get_option('tabindex', 'signed_int', true);

        if ($tag->is_required()) {
            $atts['aria-required'] = 'true';
        }

        $atts['aria-invalid'] = $validation_error ? 'true' : 'false';

        $value = (string) reset($tag->values);

        if ($tag->has_option('placeholder') || $tag->has_option('watermark')) {
            $atts['placeholder'] = $value;
            $value = '';
        }
        $value = $tag->get_default_option($value);
        $value = wpcf7_get_hangover($tag->name, $value);
        $atts['value'] = $value;
        $atts['type'] = 'text';
        $atts['name'] = $tag->name;

        $atts_lat = $atts;
        $atts_lat['data-geo'] = 'lat';
        $atts_lat['type'] = 'hidden';
        $atts_lat['name'] .= '_lat';

        $atts_lng = $atts;
        $atts_lng['data-geo'] = 'lng';
        $atts_lng['type'] = 'hidden';
        $atts_lng['name'] .= '_lng';

        $atts_formatted = $atts;
        $atts_formatted['data-geo'] = 'formatted_address';
        $atts_formatted['type'] = 'hidden';
        $atts_formatted['name'] .= '_formatted';

        $atts = wpcf7_format_atts($atts);
        $atts_lat = wpcf7_format_atts($atts_lat);
        $atts_lng = wpcf7_format_atts($atts_lng);
        $atts_formatted = wpcf7_format_atts($atts_formatted);

        ob_start();

        printf(
            '<span class="wpcf7-form-control-wrap %1$s">',
            sanitize_html_class($tag->name)
        );

        printf(
            '<input %1$s />%2$s',
            $atts,
            $validation_error
        );

        $latlng_container = 'map_latlng_' . rand(100000, 999999);
        echo '<span id="' . $latlng_container . '">';
        printf('<input %1$s />', $atts_lat);
        printf('<input %1$s />', $atts_lng);
        printf('<input %1$s />', $atts_formatted);
        echo '</span>';

        $canvas_name = 'map_canvas_' . rand(100000, 999999);
        $map_width = intval($tag->get_option('width', 'int', true));
        $map_height = intval($tag->get_option('width', 'int', true));
        if ($map_width == 0) {
            $map_width = 600;
        }
        if ($map_height == 0) {
            $map_height = 400;
        }

        if ($tag->has_option('map')) {
            ?>
            <br><div
                id="<?php echo $canvas_name; ?>"
                style="width:<?php
                echo $map_width;
                ?>px;height:<?php
                echo $map_height;
                ?>px"></div>
            <?php
        }

        $jqselector = 'input[name=' .
            preg_replace('/[' . preg_quote('!"#$%&\'()*+,./:;<=>?@[\]^`{|}~', '/') . ']/', '\\\\$0', $tag->name) .
            ']';

        $initial_location = (string)reset($tag->values);

            ?>
        <script>
        jQuery(document).ready(function() {
            /* jshint ignore:start */
            var map = <?php echo $tag->has_option('map') ? 'true' : 'false';?>;
            var canvas_name = '<?php echo $canvas_name;?>';
            jQuery('<?php echo $jqselector; ?>').geocomplete({
                details: '#<?php echo $latlng_container; ?>',
                detailsAttribute: 'data-geo',
                map: map ? ('#' + canvas_name) : false,
                location: <?php echo $initial_location ? ("'" . addslashes($initial_location) . "'") : 'false'; ?>,
                types: []
            });
            /* jshint ignore:end */
        });
        </script>
        </span>
        <?php
        $r = ob_get_contents();
        ob_end_clean();
        return $r;
    }

    /**
     * Set up tag generators for the admin area
     *
     * @since 1.0.0
     *
     */
    public function adminInit()
    {
        if (class_exists('WPCF7_TagGenerator')) {
            $tag_generator = WPCF7_TagGenerator::get_instance();
            $tag_generator->add(
                'variable',
                __('variable', 'pvb-cf7-calculator'),
                array($this, 'variableTagGenerator')
            );
            $tag_generator->add(
                'address',
                __('address', 'pvb-cf7-calculator'),
                array($this, 'addressTagGenerator')
            );
            $tag_generator->add(
                'spreadsheet_list',
                __('spreadsheet list', 'pvb-cf7-calculator'),
                array($this, 'spreadsheetListTagGenerator')
            );
            $tag_generator->add(
                'spreadsheet_reference',
                __('spreadsheet reference', 'pvb-cf7-calculator'),
                array($this, 'spreadsheetReferenceTagGenerator')
            );
            $tag_generator->add(
                'calculation',
                __('calculation', 'pvb-cf7-calculator'),
                array($this, 'calculationTagGenerator')
            );
            $tag_generator->add(
                'calculate_button',
                __('calculate button', 'pvb-cf7-calculator'),
                array($this, 'calculateButtonTagGenerator')
            );
            $tag_generator->add(
                'paypal',
                __('PayPal button', 'pvb-cf7-calculator'),
                array($this, 'paypalTagGenerator')
            );
            $tag_generator->add(
                'stripe',
                __('Stripe button', 'pvb-cf7-calculator'),
                array($this, 'stripeTagGenerator')
            );
            $tag_generator->add(
                'order_id',
                __('Order ID', 'pvb-cf7-calculator'),
                array($this, 'orderIdTagGenerator')
            );
        }
    }

    /**
     * Hook for ajax requests. Sends POST values to the form calculator and outputs the results in JSON format.
     *
     * @since 1.0.0
     *
     */
    public function ajaxCalculate()
    {
        $r = array(); // Return values will be stored here
        $input = $_POST;
        if (!empty($input['pvb_form_id'])) {
            $form = WPCF7_ContactForm::get_instance($input['pvb_form_id']);
            if ($form !== false) {
                $r = $this->calculateForm($form, $input);
            }
        }
        wp_send_json($r);
    }

    /**
     * Display a dialog to generate a "calculate" button in the form
     *
     * @param WPCF7_ContactForm $contact_form
     * @param array $options
     * @return string
     * @since 1.0.0
     *
     */
    public function calculateButtonTagGenerator($contact_form, $options)
    {
        $data = array(
            'args' => wp_parse_args($options, array()),
            'type' => 'calculate_button'
        );
        $this->loadView('tag-generator-calculate-button', $data);
    }

    /**
     * Process "calculate" button tags
     *
     * @param WPCF7_FormTag $tag
     * @return string
     * @since 1.0.0
     *
     */
    public function calculateButtonTagHandler($tag)
    {
        $class = wpcf7_form_controls_class($tag->type, 'wpcf7-calculate_button');

        $atts = array();

        $atts['class'] = $tag->get_class_option($class) . " cf7-calculate_button";
        $atts['id'] = $tag->get_id_option();
        $atts['tabindex'] = $tag->get_option('tabindex', 'signed_int', true);

        if ($tag->has_option('autocalc')) {
            $atts['class'] .= ' autocalc';
        }
        if ($tag->has_option('cf7-hide')) {
            $atts['class'] .= ' pvb-display-none';
        }

        $value = isset($tag->values[0]) ? $tag->values[0] : '';

        if (empty($value)) {
            $value = __('Calculate', 'pvb-cf7-calculator');
        }

        $atts['type'] = 'button';
        $atts['value'] = $value;

        $atts = wpcf7_format_atts($atts);

        $html = sprintf('<input %1$s />', $atts);

        return $html;
    }

    /**
     * Calculate all "variable" and "calculation" values for a given form
     *
     * @param WPCF7_ContactForm $form
     * @param array $input POST values
     * @return array
     * @since 1.0.0
     *
     */
    public function calculateForm($form, $input)
    {
        $r = array(); // Return values will be stored here
        $tags = $form->scan_form_tags();
        foreach ($tags as $tag) {
            if (empty($tag['name'])) {
                continue;
            } elseif ($tag['basetype'] == 'variable') {
                $r['raw'][$tag['name']] = $this->calculateEnum($tag['values'], $input);
                $r['formatted'][$tag['name']] = $this->addSeparators(
                    $r['raw'][$tag['name']]
                );
                $input[$tag['name']] = $r['formatted'][$tag['name']];
            } elseif ($tag['basetype'] == 'spreadsheet_reference') {
                $options = $this->extractOptions($tag);
                $r['raw'][$tag['name']] = $this->calculateSheetEnum(
                    $options['field'],
                    $tag['values'],
                    $options['sheet'],
                    str_replace('-', ':', $options['cells']),
                    $input
                );
                $r['formatted'][$tag['name']] = $this->addSeparators(
                    $r['raw'][$tag['name']]
                );
                $input[$tag['name']] = $r['formatted'][$tag['name']];
            } elseif ($tag['basetype'] == 'calculation') {
                $r['raw'][$tag['name']] = $this->calculateEquation(
                    $form,
                    $tag['values'],
                    $input,
                    $tag
                );
                $r['formatted'][$tag['name']] = $this->addSeparators(
                    $r['raw'][$tag['name']]
                );
                $input[$tag['name']] = $r['formatted'][$tag['name']];
                $_POST[$tag['name']] = $r['formatted'][$tag['name']];
            }
        }
        return $r;
    }

    /**
     * Display a dialog to generate a "calculation" field in the form
     *
     * @param WPCF7_ContactForm $contact_form
     * @param array $options
     * @since 1.0.0
     *
     */
    public function calculationTagGenerator($contact_form, $options)
    {
        $data = array(
            'args' => wp_parse_args($options, array()),
            'type' => 'calculation'
        );
        $this->loadView('tag-generator-calculation', $data);
    }

    /**
     * Process "calculation" form tags
     *
     * @param WPCF7_FormTag $tag
     * @return string
     * @since 1.0.0
     *
     */
    public function calculationTagHandler($tag)
    {

        $tag = new WPCF7_FormTag($tag);
        if (empty($tag->name)) {
            return '';
        }

        $validation_error = wpcf7_get_validation_error($tag->name);

        $class = wpcf7_form_controls_class($tag->type, 'wpcf7-calculation');

        if ($validation_error) {
            $class .= ' wpcf7-not-valid';
        }

        $atts = array();

        $atts['size'] = $tag->get_size_option('40');
        $atts['maxlength'] = $tag->get_maxlength_option();
        $atts['minlength'] = $tag->get_minlength_option();

        if ($atts['maxlength'] && $atts['minlength'] && $atts['maxlength'] < $atts['minlength']) {
            unset($atts['maxlength'], $atts['minlength']);
        }

        $atts['class'] = $tag->get_class_option($class);

        $cf_label = false;
        if ($tag->has_option('cf7-hide')) {
            $atts['class'] .= " pvb-display-none";
        }
        
        $atts['class'] .= " cf7-calculation";
        $atts['id'] = $tag->get_id_option();
        $atts['tabindex'] = $tag->get_option('tabindex', 'int', true);

        $atts['readonly'] = 'readonly';


        if ($tag->is_required()) {
            $atts['aria-required'] = 'true';
        }

        $atts['aria-invalid'] = $validation_error ? 'true' : 'false';

        $value = (string) $tag->get_option('init', '', true);

        if ($tag->has_option('placeholder') || $tag->has_option('watermark')) {
            $atts['placeholder'] = $value;
            $value = '';
        }

        $value = $tag->get_default_option($value);

        $value = wpcf7_get_hangover($tag->name, $value);

        $scval = do_shortcode('['.$value.']');
        if ($scval != '['.$value.']') {
            $value = esc_attr($scval);
        }
        $atts['value'] = $value;

        $atts['type'] = 'text';

        $atts['name'] = $tag->name;

        $atts = wpcf7_format_atts($atts);

        $html = sprintf(
            '<span class="wpcf7-form-control-wrap %1$s"><input %2$s />%3$s</span>',
            sanitize_html_class($tag->name),
            $atts,
            $validation_error
        );
        
        return $html;
    }

    /**
     * Sets up the form tags and hooks supported by this plugin
     *
     * @since 1.0.0
     *
     */
    public function cf7Init()
    {
        wpcf7_add_form_tag(
            array('address', 'address*'),
            array($this, 'addressTagHandler'),
            true
        );
        wpcf7_add_form_tag(
            array('calculate_button'),
            array($this, 'calculateButtonTagHandler'),
            true
        );
        wpcf7_add_form_tag(
            array('calculation', 'calculation*'),
            array($this, 'calculationTagHandler'),
            true
        );
        wpcf7_add_form_tag(
            array('order_id', 'order_id*'),
            array($this, 'orderIdTagHandler'),
            true
        );
        wpcf7_add_form_tag(
            array('paypal', 'paypal*'),
            array($this, 'paypalTagHandler'),
            true
        );
        wpcf7_add_form_tag(
            array('stripe', 'stripe*'),
            array($this, 'stripeTagHandler'),
            true
        );
        wpcf7_add_form_tag(
            array('variable', 'variable*'),
            array($this, 'variableTagHandler'),
            true
        );
        wpcf7_add_form_tag(
            array(
                'spreadsheet_list',
                'spreadsheet_list*',
                'spreadsheet_dropdown',
                'spreadsheet_dropdown*'
            ),
            array($this, 'spreadsheetListTagHandler'),
            true
        );
        wpcf7_add_form_tag(
            array('spreadsheet_reference', 'spreadsheet_reference*'),
            array($this, 'spreadsheetReferenceTagHandler'),
            true
        );
        add_action('wp_enqueue_scripts', array($this, 'enqueueScripts'));
        add_action('wp_ajax_pvb_calculate', array($this, 'ajaxCalculate'));
        add_action('wp_ajax_nopriv_pvb_calculate', array($this, 'ajaxCalculate'));
        add_action('wp_ajax_pvb_stripe_capture', array($this, 'stripeCapture'));
        add_action(
            'wp_ajax_nopriv_stripe_capture',
            array($this, 'stripeCapture')
        );

        $this->interceptSubmit();
    }

    /**
     * Enqueue front-end javascript
     *
     * @since 1.0.0
     *
     */
    public function enqueueScripts()
    {

        // CSS
        wp_enqueue_style(
            'pvb-cf7-calculator',
            plugins_url(
                'css/pvb-cf7-calculator.css',
                dirname(__FILE__)
            )
        );

        wp_enqueue_script(
            'pvb-cf7-calculator',           // handle
            plugins_url(
                'js/pvb-cf7-calculator.js',
                dirname(__FILE__)
            ),                              // url
            array('jquery'),                // dependencies
            $this->pluginVersion,           // version
            true                            // in footer
        );

        // Script variables
        $decimal_separator = wpSettingsFramework\wpsf_get_setting(
            self::SETTINGS_PAGE,
            'features',
            'decimal_separator'
        );
        if (empty($decimal_separator)) {
            $decimal_separator = '.';
        }

        $thousands_separator = wpSettingsFramework\wpsf_get_setting(
            self::SETTINGS_PAGE,
            'features',
            'thousands_separator'
        );

        $preserve_fields = wpSettingsFramework\wpsf_get_setting(
            self::SETTINGS_PAGE,
            'features',
            'preserve_fields'
        );

        wp_localize_script(
            'pvb-cf7-calculator',
            'pvbdata',
            array(
                'ajaxurl' => admin_url('admin-ajax.php'),
                'decimal_separator' => $decimal_separator,
                'thousands_separator' => $thousands_separator,
                'preserve_fields' => $preserve_fields,
                'msg_calculating' => __('Calculating...', 'pvb-cf7-calculator')
            )
        );
    }

    /**
     * Display a notice in the admin area if CF7 not installed, not active, or too old
     *
     * @since 1.0.0
     *
     */
    public function notActiveNotice()
    {
        $this->loadView('not-active-notice');
    }

    /**
     * Initialize the plugin
     *
     * @since 1.0.0
     *
     */
    public function init()
    {
        load_plugin_textdomain('pvb-cf7-calculator', false, PVB_CF7_CALCULATOR_PRO_PATH . '/languages');

        add_filter(
            'plugin_action_links_' . plugin_basename(PVB_CF7_CALCULATOR_PRO_PATH . '/pvb-cf7-calculator.php'),
            array($this, 'pluginActionLinks')
        );

        if (!$this->checkCF7()) {
            add_action('admin_notices', array($this, 'notActiveNotice'));
        }
    }

    /**
     * Display a dialog to generate a PayPal button in the form
     *
     * @param WPCF7_ContactForm $contact_form
     * @param array $options
     * @since 1.5.0
     *
     */
    public function paypalTagGenerator($contact_form, $options)
    {
        $data = array(
            'args' => wp_parse_args($options, array()),
            'type' => 'paypal'
        );
        $this->loadView('tag-generator-paypal', $data);
    }

    /**
     * Display a dialog to generate an order ID field tag
     *
     * @param WPCF7_ContactForm $contact_form
     * @param array $options
     * @since 1.6.4
     *
     */
    public function orderIdTagGenerator($contact_form, $options)
    {
        $data = array(
            'args' => wp_parse_args($options, array()),
            'type' => 'order_id'
        );
        $this->loadView('tag-generator-order-id', $data);
    }

    /**
     * Generate a unique order ID
     *
     * @param WPCF7_FormTag $tag
     * @param array $options
     * @since 1.6.4
     *
     */
    public function orderIdTagHandler($tag)
    {
        $tag = new WPCF7_FormTag($tag);
        if (empty($tag->name)) {
            return '';
        }

        $class = wpcf7_form_controls_class($tag->type, 'wpcf7-order-id');

        $atts = array();

        $atts['size'] = $tag->get_size_option('40');
        $atts['class'] = $tag->get_class_option($class);

        $cf_label = false;

        if($tag->has_option('cf7-hide')) {
            $atts['class'] .=" pvb-display-none";
        }
        
        $atts['id'] = $tag->get_id_option();
        $atts['tabindex'] = $tag->get_option('tabindex', 'int', true);

        $atts['readonly'] = 'readonly';

        $value = strtoupper(base_convert(
            crc32($_SERVER['REMOTE_ADDR'] . microtime() . mt_rand()),
            10,
            36
        ));

        $atts['value'] = $value;
        $atts['type'] = 'text';
        $atts['name'] = $tag->name;
        $atts = wpcf7_format_atts($atts);

        $html = sprintf(
            '<span class="wpcf7-form-control-wrap %1$s"><input %2$s />%3$s</span>',
            sanitize_html_class($tag->name),
            $atts,
            $validation_error
        );
        
        return $html;
    }

    /**
     * Process PayPal button tags
     *
     * @param WPCF7_FormTag $tag
     * @return string
     * @since 1.5.0
     *
     */
    public function paypalTagHandler($tag)
    {
        $data = array(
            'extra_classes' => $tag->get_class_option(''),
            'id' => md5(uniqid(mt_rand(), true)),
            'email' => (string) $tag->get_option('email', '', true),
            'item_name' => (string) reset($tag->values),
            'field' => (string) $tag->get_option('field', '', true),
            'currency' => (string) $tag->get_option('currency', '', true),
            'payonsubmit' => $tag->has_option('payonsubmit'),
            'newtab' => $tag->has_option('newtab'),
            'return' => '',
            'cancel_return' => ''
        );

        // Thank you pages
        $success_page = (string) $tag->get_option('success', '', true);
        $fail_page = (string) $tag->get_option('fail', '', true);

        if (!empty($success_page)) {
            $post = get_page_by_path($success_page);
            $data['return'] = get_permalink($post->ID);
        }

        if (!empty($fail_page)) {
            $post = get_page_by_path($fail_page);
            $data['cancel_return'] = get_permalink($post->ID);
        }

        ob_start();
        $this->loadView('paypal-button', $data);
        $r = ob_get_contents();
        ob_end_clean();
        return $r;
    }

    /**
     * Add "Settings" and "Support" links on Plugins page
     *
     * @since 1.2.0
     *
     */
    public function pluginActionLinks($links)
    {
        $settings_page_slug = sprintf('%s-settings', str_replace('_', '-', self::SETTINGS_PAGE));
        $links[] = '<a href="'. esc_url(menu_page_url($settings_page_slug, false)) .'">Settings</a>';
        $links[] = '<a href="https://bossakov.eu/connect/" target="_blank">Support</a>';
        return $links;
    }

    /**
     * Add a settings page to the admin menu
     *
     * @since 1.2.0
     *
     */
    public function settingsMenu()
    {
        $this->wpsf->add_settings_page(array(
            'parent_slug' => 'wpcf7',
            'page_title' => __('Calculator Settings', 'pvb-cf7-calculator'),
            'menu_title' => __('Calculator Settings', 'pvb-cf7-calculator'),
            'capability' => 'manage_options'
        ));
    }

    /**
     * Process "spreadsheet_dropdown" and "spreadsheet_list" form tags
     *
     * @param WPCF7_FormTag $tag
     * @return string
     * @since 1.3.0
     *
     */
    public function spreadsheetListTagHandler($tag)
    {
        $tag = new WPCF7_FormTag($tag);
        if (empty($tag->name)) {
            return '';
        }

        $document = isset($tag->values[0]) ? $tag->values[0] : '';
        $sheet = (array)$tag->get_option('sheet');
        $sheet = array_shift($sheet);
        $cells = (array)$tag->get_option('cells');
        $cells = array_shift($cells);
        $cells = str_replace('-', ':', $cells);
        $labels = array();
        $values = array();

        try {
            $range = $this->getRangeFromSpreadsheet($document, $sheet, $cells);
            foreach ($range as $key => $row) {
                if (isset($row[1])) {
                    $labels[] = $row[0];
                    $values[] = $row[1];
                } else {
                    $values[] = $row[0];
                }
            }
        } catch (\Exception $e) {
            $values = array(__($e->getMessage(), 'pvb-cf7-calculator'));
        }

        $field_type = (string) $tag->get_option('type', '', true);

        if ($field_type == 'checkbox') {
            return $this->spreadsheetListCheckboxes($tag, $labels, $values);
        } elseif ($field_type == 'radio') {
            return $this->spreadsheetListRadio($tag, $labels, $values);
        } else {
            return $this->spreadsheetListDropDown($tag, $labels, $values);
        }

    }

    /**
     * Process "spreadsheet_reference" form tags
     *
     * @param WPCF7_FormTag $tag
     * @return string
     * @since 1.3.0
     *
     */
    public function spreadsheetReferenceTagHandler($tag)
    {
        $tag = new WPCF7_FormTag($tag);
        if (empty($tag->name)) {
            return '';
        }

        $validation_error = wpcf7_get_validation_error($tag->name);

        $class = wpcf7_form_controls_class($tag->type, 'wpcf7-spreadsheet_reference');

        if ($validation_error) {
            $class .= ' wpcf7-not-valid';
        }

        $atts = array();

        $atts['size'] = $tag->get_size_option('40');
        $atts['maxlength'] = $tag->get_maxlength_option();
        $atts['minlength'] = $tag->get_minlength_option();

        if ($atts['maxlength'] && $atts['minlength'] && $atts['maxlength'] < $atts['minlength']) {
            unset($atts['maxlength'], $atts['minlength']);
        }

        $atts['class'] = $tag->get_class_option($class);

        $cf_label = false;

        if ($tag->has_option('cf7-hide')) {
            $atts['class'] .= ' pvb-display-none';
        }
        
        $atts['class'] .= " cf7-spreadsheet_reference";
        $atts['id'] = $tag->get_id_option();
        $atts['tabindex'] = $tag->get_option('tabindex', 'int', true);

        $atts['readonly'] = 'readonly';


        if ($tag->is_required()) {
            $atts['aria-required'] = 'true';
        }

        $atts['aria-invalid'] = $validation_error ? 'true' : 'false';

        $value = (string) reset($tag->values);


        if ($tag->has_option('placeholder') || $tag->has_option('watermark')) {
            $atts['placeholder'] = $value;
            $value = '';
        }

        $value = $tag->get_default_option($value);

        $value = wpcf7_get_hangover($tag->name, $value);

        $scval = do_shortcode('['.$value.']');
        if ($scval != '['.$value.']') {
            $value = esc_attr($scval);
        }
        $atts['value'] = 0;

        $atts['type'] = 'text';

        $atts['name'] = $tag->name;

        $atts = wpcf7_format_atts($atts);

        $html = sprintf(
            '<span class="wpcf7-form-control-wrap %1$s"><input %2$s />%3$s</span>',
            sanitize_html_class($tag->name),
            $atts,
            $validation_error
        );
        
        return $html;
    }

    /**
     * Display a dialog to generate a "spreadsheet list" field in the form
     *
     * @param WPCF7_ContactForm $contact_form
     * @param array $options
     * @since 1.3.0
     *
     */
    public function spreadsheetListTagGenerator($contact_form, $options)
    {
        $data = array(
            'args' => wp_parse_args($options, array()),
            'type' => 'spreadsheet_list'
        );
        $this->loadView('tag-generator-spreadsheet-list', $data);
    }

    /**
     * Display a dialog to generate a "spreadsheet reference" field in the form
     *
     * @param WPCF7_ContactForm $contact_form
     * @param array $options
     * @since 1.3.0
     *
     */
    public function spreadsheetReferenceTagGenerator($contact_form, $options)
    {
        $data = array(
            'args' => wp_parse_args($options, array()),
            'type' => 'spreadsheet_reference'
        );
        $this->loadView('tag-generator-spreadsheet-reference', $data);
    }

    /**
     * Hook for ajax requests. Initiates a Stripe charge and returns the result.
     *
     * @since 1.6.0
     *
     */
    public function stripeCapture()
    {
        $r = array(); // Return values will be stored here
        $live_mode = wpSettingsFramework\wpsf_get_setting(
            self::SETTINGS_PAGE,
            'stripe',
            'stripe_live'
        );
        $secret_key = wpSettingsFramework\wpsf_get_setting(
            self::SETTINGS_PAGE,
            'stripe',
            ($live_mode == 1) ? 'stripe_secret_key' : 'stripe_secret_key_test'
        );

        $postdata = array(
            'amount' => $_POST['amount'] * ($_POST['zerodecimal'] ? 1 : 100),
            'currency' => $_POST['currency'],
            'description' => $_POST['item_name'],
            'source' => $_POST['token']
        );

        if (empty($postdata['currency'])) {
            $data['currency'] = 'USD';
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.stripe.com/v1/charges");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postdata));
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_USERPWD, $secret_key . ":" . "");

        $headers = array();
        $headers[] = "Content-Type: application/x-www-form-urlencoded";
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            $r['error'] = curl_error($ch);
        }
        curl_close($ch);

        $result = json_decode($result);
        $r['success'] = false;
        if (!empty($result) && !empty($result->outcome)) {
            if ($result->outcome->network_status == 'approved_by_network') {
                $r['success'] = true;
            }
        }
        wp_send_json($r);
    }

    /**
     * Display a dialog to generate a Stripe button in the form
     *
     * @param WPCF7_ContactForm $contact_form
     * @param array $options
     * @since 1.6.0
     *
     */
    public function stripeTagGenerator($contact_form, $options)
    {
        $data = array(
            'args' => wp_parse_args($options, array()),
            'type' => 'stripe'
        );
        $this->loadView('tag-generator-stripe', $data);
    }

    /**
     * Process Stripe button tags
     *
     * @param WPCF7_FormTag $tag
     * @return string
     * @since 1.6.0
     *
     */
    public function stripeTagHandler($tag)
    {
        $data = array(
            'extra_classes' => $tag->get_class_option(''),
            'id' => md5(uniqid(mt_rand(), true)),
            'item_name' => (string) reset($tag->values),
            'field' => (string) $tag->get_option('field', '', true),
            'emailfield' => (string) $tag->get_option('emailfield', '', true),
            'currency' => trim(strtoupper(
                (string) $tag->get_option('currency', '', true)
            )),
            'zerodecimal' => '0',
            'payonsubmit' => $tag->has_option('payonsubmit'),
            'success_url' => '',
            'fail_url' => ''
        );

        $live_mode = wpSettingsFramework\wpsf_get_setting(
            self::SETTINGS_PAGE,
            'stripe',
            'stripe_live'
        );

        $data['stripe_key'] = wpSettingsFramework\wpsf_get_setting(
            self::SETTINGS_PAGE,
            'stripe',
            ($live_mode == 1) ?
                'stripe_publishable_key' :
                'stripe_publishable_key_test'
        );

        if (empty($data['currency'])) {
            $data['currency'] = 'USD';
        }

        $zerodecimal_currencies = array(
            'CLP',
            'DJF',
            'GNF',
            'JPY',
            'KMF',
            'KRW',
            'MGA',
            'PYG',
            'RWF',
            'UGX',
            'VND',
            'VUV',
            'XAF',
            'XOF',
            'XPF'
        );
        if (in_array($data['currency'], $zerodecimal_currencies)) {
            $data['zerodecimal'] = '1';
        }

        // Thank you pages
        $success_page = (string) $tag->get_option('success', '', true);
        $fail_page = (string) $tag->get_option('fail', '', true);

        if (!empty($success_page)) {
            $post = get_page_by_path($success_page);
            $data['success_url'] = get_permalink($post->ID);
        }

        if (!empty($fail_page)) {
            $post = get_page_by_path($fail_page);
            $data['fail_url'] = get_permalink($post->ID);
        }

        ob_start();
        $this->loadView('stripe-button', $data);
        $r = ob_get_contents();
        ob_end_clean();
        return $r;
    }

    /**
     * Display a dialog to generate a "calculation" field in the form
     *
     * @param WPCF7_ContactForm $contact_form
     * @param array $options
     * @since 1.0.0
     *
     */
    public function variableTagGenerator($contact_form, $options)
    {
        $data = array(
            'args' => wp_parse_args($options, array()),
            'type' => 'variable'
        );
        $this->loadView('tag-generator-variable', $data);
    }

    /**
     * Process "variable" form tags
     *
     * @param WPCF7_FormTag $tag
     * @return string
     * @since 1.0.0
     *
     */
    public function variableTagHandler($tag)
    {
        $tag = new WPCF7_FormTag($tag);
        if (empty($tag->name)) {
            return '';
        }

        $validation_error = wpcf7_get_validation_error($tag->name);

        $class = wpcf7_form_controls_class($tag->type, 'wpcf7-variable');

        if ($validation_error) {
            $class .= ' wpcf7-not-valid';
        }

        $atts = array();

        $atts['size'] = $tag->get_size_option('40');
        $atts['maxlength'] = $tag->get_maxlength_option();
        $atts['minlength'] = $tag->get_minlength_option();

        if ($atts['maxlength'] && $atts['minlength'] && $atts['maxlength'] < $atts['minlength']) {
            unset($atts['maxlength'], $atts['minlength']);
        }

        $atts['class'] = $tag->get_class_option($class);

        $cf_label = false;

        if ($tag->has_option('cf7-hide')) {
            $atts['class'] .= ' pvb-display-none';
        }
        
        $atts['class'] .= " cf7-variable";
        $atts['id'] = $tag->get_id_option();
        $atts['tabindex'] = $tag->get_option('tabindex', 'int', true);

        $atts['readonly'] = 'readonly';


        if ($tag->is_required()) {
            $atts['aria-required'] = 'true';
        }

        $atts['aria-invalid'] = $validation_error ? 'true' : 'false';

        $value = (string) $tag->get_option('init', '', true);;


        if ($tag->has_option('placeholder') || $tag->has_option('watermark')) {
            $atts['placeholder'] = $value;
            $value = '';
        }

        $value = $tag->get_default_option($value);

        $value = wpcf7_get_hangover($tag->name, $value);

        $scval = do_shortcode('['.$value.']');
        if ($scval != '['.$value.']') {
            $value = esc_attr($scval);
        }
        $atts['value'] = $value;

        $atts['type'] = 'text';

        $atts['name'] = $tag->name;

        $atts = wpcf7_format_atts($atts);

        $html = sprintf(
            '<span class="wpcf7-form-control-wrap %1$s"><input %2$s />%3$s</span>',
            sanitize_html_class($tag->name),
            $atts,
            $validation_error
        );
        
        return $html;
    }

    /**
     * Calculates the value of a "variable" field based on user input
     *
     * @param string[] $values field map
     * @param array $input POST values
     * @return float
     * @since 1.0.0
     *
     */
    private function calculateEnum($values, $input)
    {
        $map = array(); // string values will be mapped to numeric values here
        $target_field = ''; // which input field to map

        foreach ($values as $line) {
            $line = rtrim($line);
            if (preg_match('/(.*)\:$/', $line, $matches)) {
                $target_field = $matches[1];
            } elseif (preg_match('/(.*)\s+([0-9\.]+)$/', $line, $matches)) {
                if (strtolower(trim($matches[1])) == 'default') {
                    $map['default'] = $matches[2];
                }
                $map[md5($matches[1])] = $matches[2];
            }
        }

        if (empty($map['default'])) {
            $map['default'] = 0;
        }

        $r = 0;
        $default = true;

        if (empty($target_field)) {
            // NOP
        } elseif (!isset($input[$target_field])) {
            // NOP
        } else {
            $in = (array) $input[$target_field];
            foreach ($in as $input_value) {
                if (!isset($input_value)) {
                    // NOP
                } elseif (!isset($map[md5($input_value)])) {
                    // NOP
                } else {
                    $r += $map[md5($input_value)];
                    $default = false;
                }
            }
        }

        if ($default) {
            return $map['default'];
        } else {
            return $r;
        }
    }

    /**
     * Calculate the value of a "calculation" field based on user input
     *
     * @param WPCF7_ContactForm $form
     * @param string[] $values formula
     * @param array $input POST values
     * @return float
     * @since 1.0.0
     *
     */
    private function calculateEquation($form, $values, $input, $tag)
    {

        $options = $this->extractOptions($tag);

        if (is_array($values)) {
            $values = implode(' ', $values);
        }

        if (empty($values) || empty($input)) {
            return 0;
        }

        $expression = html_entity_decode($values);

        // Run PHP code if allowed (default is off)
        $php_allowed = wpSettingsFramework\wpsf_get_setting(self::SETTINGS_PAGE, 'features', 'allow_eval');

        if ($php_allowed) {
            do {
                try {
                    $tmp = $this->evalNextPHP($expression);
                } catch (\Exception $e) {
                    return __($e->getMessage(), 'pvb-cf7-calculator');
                }
                if ($tmp !== false) {
                    $expression = $tmp;
                }
            } while ($tmp !== false);
        } else {
            // PHP not allowed in settings
            // Return an error if we have a PHP expression in the formula
            if (preg_match('/(^|\s|[\+\-\*\/\(\)])fn_php *\(/', $expression)) {
                return __('PHP code not enabled in calculators, please check your settings.', 'pvb-cf7-calculator');
            }
        }

        // Process spreadsheet references
        if (preg_match('/(^|\s|[\+\-\*\/\(\)])fn_spreadsheet *\((.*?)\)/', $expression, $matches, PREG_OFFSET_CAPTURE)) {
            $fn_offset = $matches[0][1];
            $fn_length = strlen($matches[0][0]);
            $params = $matches[2][0];
            $params = str_replace('\)', ')', $params);
            $params = str_replace('\,', '###COMMA###', $params);
            $params = explode(',', $params);
            foreach ($params as $key => $param) {
                $params[$key] = str_replace('###COMMA###', ',', trim($param));
            }
            $file = $params[0];
            $sheet_idx = $params[1];
            $col = $params[2];
            $row = $params[3];
            if (preg_match('/^[A-Z]+$/', strtoupper($col))) {
                // Convert Excel-style column letter [A, B, C, ...) to numeric index
                $col = PhpSpreadsheet\Cell\Coordinate::columnIndexFromString(strtoupper($col));
            }
            if (empty($file) || !is_numeric($sheet_idx) || !is_numeric($row) || !is_numeric($col)) {
                return __('fn_spreadsheet: invalid parameters', 'pvb-cf7-calculator');
            }

            try {
                $value = $this->getValueFromSpreadsheet($file, $sheet_idx, $col, $row);
            } catch (\Exception $e) {
                return __($e->getMessage(), 'pvb-cf7-calculator');
            }

            $expression = substr($expression, 0, $fn_offset) .
                $matches[1][0] .
                (float)$value .
                substr($expression, $fn_offset + $fn_length);
        }

        // Process distance
        if (preg_match('/(^|\s|[\+\-\*\/\(\)])fn_distance *\((.*?)\)/', $expression, $matches, PREG_OFFSET_CAPTURE)) {
            $fn_offset = $matches[0][1];
            $fn_length = strlen($matches[0][0]);
            $params = $this->replaceInputs($form, $matches[2][0], $input, false, ',');
            $params = str_replace('\)', ')', $params);
            $params = str_replace('\,', '###COMMA###', $params);
            $params = explode(',', $params);
            foreach ($params as $key => $param) {
                $params[$key] = str_replace('###COMMA###', ',', trim($param));
            }
            $origin = trim($params[0]);
            $destination = trim($params[1]);
            $units = strtolower(trim($params[2]));

            try {
                if (empty($origin) || empty($destination)) {
                    throw new \Exception(
                        'Cannot retrieve distance data: invalid origin/destination input'
                    );
                }

                $api_key = wpSettingsFramework\wpsf_get_setting(self::SETTINGS_PAGE, 'google', 'google_api_key');

                if (empty($api_key)) {
                    throw new \Exception(
                        'Cannot retrieve distance data: Google Maps API key not set'
                    );
                }

                $timeout = wpSettingsFramework\wpsf_get_setting(
                    self::SETTINGS_PAGE,
                    'features',
                    'csv_remote_timeout'
                );
                if ($timeout < 1) {
                    $timeout = 10;
                }

                $url = 'https://maps.googleapis.com/maps/api/distancematrix/json?units=' . $units .
                    '&origins=' . urlencode($origin) .
                    '&destinations=' . urlencode($destination) .
                    '&key=' . $api_key;

                $r = wp_remote_get($url, array(
                    'timeout' => $timeout
                ));
                if (is_wp_error($r) || $r['response']['code'] != 200) {
                    throw new \Exception(
                        'Cannot retrieve distance data: no connection with Google Maps'
                    );
                }

                $matrix = json_decode($r['body']);
                if (empty($matrix) || !isset($matrix->rows[0]->elements[0]->distance->value)) {
                    throw new \Exception(
                        'Cannot retrieve distance data, please check your input'
                    );             
                }

                $meters = $matrix->rows[0]->elements[0]->distance->value;
                switch ($units) {
                    case 'miles':
                        $value = $meters / 1609.344;
                        break;
                    case 'km':
                        $value = $meters / 1000;
                        break;
                    case 'm':
                    default:
                        $value = $meters;
                }
            } catch (\Exception $e) {
                return __($e->getMessage(), 'pvb-cf7-calculator');
            }

            $expression = substr($expression, 0, $fn_offset) .
                $matches[1][0] .
                (float)$value .
                substr($expression, $fn_offset + $fn_length);
        }

        // Process travel time
        if (preg_match('/(^|\s|[\+\-\*\/\(\)])fn_travel_time *\((.*?)\)/', $expression, $matches, PREG_OFFSET_CAPTURE)) {
            $fn_offset = $matches[0][1];
            $fn_length = strlen($matches[0][0]);
            $params = $this->replaceInputs($form, $matches[2][0], $input, false, ',');
            $params = str_replace('\)', ')', $params);
            $params = str_replace('\,', '###COMMA###', $params);
            $params = explode(',', $params);
            foreach ($params as $key => $param) {
                $params[$key] = str_replace('###COMMA###', ',', trim($param));
            }
            $origin = trim($params[0]);
            $destination = trim($params[1]);
            $units = strtolower(trim($params[2]));

            try {
                if (empty($origin) || empty($destination)) {
                    throw new \Exception(
                        'Cannot retrieve travel time data: invalid origin/destination input'
                    );
                }

                $api_key = wpSettingsFramework\wpsf_get_setting(self::SETTINGS_PAGE, 'google', 'google_api_key');

                if (empty($api_key)) {
                    throw new \Exception(
                        'Cannot retrieve travel time data: Google Maps API key not set'
                    );
                }

                $timeout = wpSettingsFramework\wpsf_get_setting(
                    self::SETTINGS_PAGE,
                    'features',
                    'csv_remote_timeout'
                );
                if ($timeout < 1) {
                    $timeout = 10;
                }

                $url = 'https://maps.googleapis.com/maps/api/distancematrix/json?units=' . $units .
                    '&origins=' . urlencode($origin) .
                    '&destinations=' . urlencode($destination) .
                    '&key=' . $api_key;

                $r = wp_remote_get($url, array(
                    'timeout' => $timeout
                ));
                if (is_wp_error($r) || $r['response']['code'] != 200) {
                    throw new \Exception(
                        'Cannot retrieve travel time data: no connection with Google Maps'
                    );
                }

                $matrix = json_decode($r['body']);
                if (empty($matrix) || !isset($matrix->rows[0]->elements[0]->duration->value)) {
                    throw new \Exception(
                        'Cannot retrieve travel time data, please check your input'
                    );
                }

                $seconds = $matrix->rows[0]->elements[0]->duration->value;
                switch ($units) {
                    case 'h':
                        $value = $seconds / 3600;
                        break;
                    case 'm':
                    default:
                        $value = $seconds / 60;
                }
            } catch (\Exception $e) {
                return __($e->getMessage(), 'pvb-cf7-calculator');
            }

            $expression = substr($expression, 0, $fn_offset) .
                $matches[1][0] .
                (float)$value .
                substr($expression, $fn_offset + $fn_length);
        }

        $expression = $this->replaceInputs($form, $expression, $input);

        // Fix nested parentheses bug
        while (preg_match('/\(\s*\(/', $expression)) {
            $expression = preg_replace('/\(\s*\(/', '(1*(', $expression);
        }
        $expression = trim($expression);

        if (self::DEBUG) {
            echo("\nEvaluating expression: $expression");
        }

        // Calculate
        if (preg_match('/^[\(0-9\.\)]+$/', $expression)) {
            $r = $expression; // It's a number, nothing to calculate
        } else {
            $calculator = PVBCalculator::create();
            try {
                $r = $calculator->calculate($expression);
            } catch (\Exception $e) {
                $r = __($e->getMessage(), 'pvb-cf7-calculator');
            }
        }
        
        // Apply minimum
        if (isset($options['min'])) {
            $r = max($r, $options['min']);
        }

        // Apply maximum
        if (isset($options['max'])) {
            $r = min($r, $options['max']);
        }

        // Apply rounding
        if (isset($options['precision'])) {
            if ($tag->has_option('roundup')) {
                $offset = 0.5;
                if (intval($options['precision']) != 0) {
                    $offset /= pow(10, intval($options['precision']));
                }
                $r = round(
                    $r + $offset,
                    $options['precision'],
                    PHP_ROUND_HALF_DOWN
                );
            } elseif ($tag->has_option('rounddown')) {
                $offset = 0.5;
                if (intval($options['precision']) != 0) {
                    $offset /= pow(10, intval($options['precision']));
                }
                $r = round(
                    $r - $offset,
                    $options['precision'],
                    PHP_ROUND_HALF_UP
                );
            } else {
                $r = round($r, $options['precision']);
            }
            $r = sprintf('%.' . $options['precision'] . 'F', $r);
        }

        return $r;
    }

    /**
     * Calculates the value of a "spreadsheet_reference" field based on user input
     *
     * @param string $target_field name of the field containing text that needs to be mapped to a value
     * @param string $document URL or local path of the spreadsheet
     * @param int $sheet number of the sheet [1..n]
     * @param string $cells range of the map table expressed in A1 notation
     * @param array $input POST values
     * @return float
     * @since 1.3.0
     *
     */
    private function calculateSheetEnum($target_field, $document, $sheet, $cells, $input)
    {
        $map = array(); // string values will be mapped to numeric values here

        try {
            $range = $this->getRangeFromSpreadsheet($document, $sheet, $cells);
        } catch (\Exception $e) {
            return __($e->getMessage(), 'pvb-cf7-calculator');
        }
        
        foreach ($range as $row) {
            if ($row[0] == 'default') {
                $map['default'] = $row[1];
            } else {
                $map[md5(strtolower(trim($row[0])))] = $row[1];
            }
        }

        if (empty($map['default'])) {
            $map['default'] = 0;
        }

        if (empty($target_field)) {
            return $map['default'];
        } elseif (!isset($input[$target_field])) {
            return $map['default'];
        } elseif (!isset($map[md5(strtolower(trim($input[$target_field])))])) {
            return $map['default'];
        } else {
            return $map[md5(strtolower(trim($input[$target_field])))];
        }
    }

    /**
     * Check if Contact Form 7 is active and its version is the one required by this plugin (or newer)
     *
     * @return boolean
     * @since 1.0.0
     *
     */
    private function checkCF7()
    {
        return defined('WPCF7_VERSION') ? version_compare(WPCF7_VERSION, self::CF7_VERSION_REQUIRED, '>=') : false;
    }

    /**
     * Download an external spreadsheet.
     *
     * @param string $file URL
     * @return string local file name
     * @throws Exception
     * @since 1.3.0
     *
     */
    private function downloadSpreadsheet($file)
    {
        // Download file if necessary
        if (!empty($this->downloaded_files[md5($file)])) {
            $tmp_path = $this->downloaded_files[md5($file)];
        } else {
            $url_components = parse_url($file);
            if ($url_components === false) {
                throw new \Exception('Cannot parse spreadsheet URL');
            }
            if (preg_match('/^http/', $url_components['scheme'])) {
                $timeout = wpSettingsFramework\wpsf_get_setting(
                    self::SETTINGS_PAGE,
                    'features',
                    'csv_remote_timeout'
                );
                if ($timeout < 1) {
                    $timeout = 10;
                }
                $tmp_file = wp_unique_filename(
                    get_temp_dir(),
                    'pvb_cf7_calculator_spreadsheet' . $this->fileExtension($file)
                );
                $r = wp_remote_get($file, array(
                    'timeout' => $timeout,
                    'stream' => true,
                    'filename' => $tmp_file
                ));
                if (is_wp_error($r) || $r['response']['code'] != 200) {
                    throw new \Exception(
                        'Cannot download remote spreadsheet'
                    );
                }
                $this->downloaded_files[md5($file)] = $tmp_file;
                $tmp_path = $tmp_file;
            } elseif ($url_components['scheme'] == 'ftp') {
                $timeout = wpSettingsFramework\wpsf_get_setting(
                    self::SETTINGS_PAGE,
                    'features',
                    'csv_remote_timeout'
                );
                if ($timeout < 1) {
                    $timeout = 10;
                }

                // set up basic connection
                $port = !empty($url_components['port']) ? $url_components['port'] : 21;
                $conn_id = ftp_connect($url_components['host'], $port, $timeout);

                if ($conn_id === false) {
                    throw new \Exception('Cannot download remote spreadsheet (FTP connect error)');
                }

                // login with username and password
                $user = $url_components['user'] ? urldecode($url_components['user']) : 'anonymous';
                $pass = $url_components['pass'] ? urldecode($url_components['pass']) : 'me@privacy.net';
                $login_result = ftp_login($conn_id, $user, $pass);
                if ($login_result === false) {
                    throw new \Exception('Cannot download remote spreadsheet (FTP login error)');
                }
                ftp_pasv($conn_id, true);

                // try to download server file and save to local file
                $tmp_file = wp_unique_filename(
                    get_temp_dir(),
                    'pvb_cf7_calculator_spreadsheet' . $this->fileExtension($file)
                );
                $tmp_path = get_temp_dir() . $tmp_file;

                $download_result = ftp_get($conn_id, $tmp_path, $url_components['path'], FTP_BINARY);
                if ($download_result === false) {
                    throw new \Exception('Cannot download remote spreadsheet (FTP download error)');
                }

                // close the connection
                ftp_close($conn_id);
                $this->downloaded_files[md5($file)] = $tmp_path;
            } else {
                throw new \Exception('Incorrect spreadsheet URL');
            }
        }
        return $tmp_path;
    }

    /**
     * Extracts attributes (such as "min", "max" and "precision") from a CF7 tag
     *
     * @param WPCF7_FormTag $tag
     * @return array
     * @since 1.0.0
     *
     */
    private function extractOptions($tag)
    {
        $r = array();
        if ($tag['options']) {
            foreach ($tag['options'] as $opt) {
                $pieces = explode(":", $opt);
                if (count($pieces) > 1) {
                    $r[$pieces[0]] = $pieces[1];
                }
            }
        }
        return $r;
    }

    /**
     * Evaluate and replace first occurence of fn_php() call in an expression
     *
     * @param string $expression formula where PHP code should be evaluated
     * @param int $start position where we should start looking for fn_php() calls
     * @return string
     * @since 1.2.0
     *
     */
    private function evalNextPHP($expression, $start = 0)
    {

        $mb = function_exists('mb_strlen');
        $position = $mb ? mb_strpos($expression, 'fn_php', 0, 'UTF-8') : strpos($expression, 'fn_php');
        $replacement = '';
        $length = '';

        if ($position !== false) {
            $match_substr = $mb ?
                mb_substr($expression, max(0, $position-1), null, 'UTF-8') :
                substr($expression, max(0, $position-1));

            if (preg_match('/^(\s|[\+\-\*\/\(\)])?fn_php\s*\(/', $match_substr, $matches)) {
                $code_start = ($mb ? mb_strlen($matches[0], 'UTF-8') : strlen($matches[0]));
                $code = $this->getStringUntilClosingParenthesis($match_substr, $code_start);
                $length = $mb ? mb_strlen($code, 'UTF-8') : strlen($code);
                if (self::DEBUG) {
                    echo("Running eval on code: $code");
                }
                $eval_result = @eval($code);
                if ($eval_result === false) {
                    throw new \Exception("Error in eval'd PHP code");
                } elseif ($eval_result === null) {
                    $replacement = 0;
                } else {
                    $replacement = (float) $eval_result;
                }
            }
        } else {
            return false;
        }

        if ($length > 0) {
            return substr($expression, 0, $position) .
                $replacement .
                preg_replace('/^\)/', '', substr($expression, $position + $code_start + $length));
        } else {
            $next = $this->evalNextPHP(substr($expression, $position + 1));
            if ($next === false) {
                return false;
            } else {
                return substr($expression, 0, $position + 1) . $next;
            }
        }
    }

    /**
     * Extract file extension part from a string, including leading dot
     *
     * @param string
     * @return string file extension (leading dot included) or empty
     * @since 1.3.0
     *
     */
    private function fileExtension($string)
    {
        if (preg_match('/\.([a-z0-9]{1,4})$/i', $string, $matches)) {
            return $matches[0];
        } else {
            return "";
        }
    }

    /**
     * Obtain a value from a Google sheet.
     *
     * @param string $sheet_id ID of the sheet extracted from URL,
     *               e.g. https://docs.google.com/spreadsheets/d/1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms/edit
     * @param int $sheet_idx number of sheet in file [1..n]
     * @param int $column [1..n]
     * @param int $row [1..n]
     * @return mixed cell value
     * @since 1.3.0
     *
     */
    private function getValueFromGoogleSheet($sheet_id, $sheet_idx, $column, $row)
    {
        $api_key = wpSettingsFramework\wpsf_get_setting(self::SETTINGS_PAGE, 'google', 'google_api_key');
        if (empty($api_key)) {
            throw new \Exception(
                'You must set a valid Google API key in the Calculator Settings area in order to access Google Sheets.'
            );
        }
        $client = new \Google_Client();
        $client->setDeveloperKey($api_key);
        $service = new \Google_Service_Sheets($client);

        if (preg_match('/^[A-Z]+$/', strtoupper($column))) {
            $letter = $column;
        } else {
            $letter = PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($column);
        }
        
        $range = $letter . $row;

        try {
            $spreadsheet = $service->spreadsheets->get($sheet_id, array(
                'ranges' => $range,
                'includeGridData' => true));
            return $spreadsheet->sheets[$sheet_idx-1]->data[0]->rowData[0]->values[0]->effectiveValue->numberValue;
        } catch (\Exception $e) {
            throw new \Exception('Error retrieving data from Google Sheets.');
        }
    }

    /**
     * Obtain a two-column range from a Google sheet as an array.
     *
     * @param string $sheet_id ID of the sheet extracted from URL,
     *               e.g. https://docs.google.com/spreadsheets/d/1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms/edit
     * @param int $sheet_idx number of sheet in file [1..n]
     * @param string $range A1 notation
     * @return array[] 2-dimensional array of rows and cells
     * @since 1.3.0
     *
     */
    private function getRangeFromGoogleSheet($sheet_id, $sheet_idx, $range)
    {
        $api_key = wpSettingsFramework\wpsf_get_setting(self::SETTINGS_PAGE, 'google', 'google_api_key');
        if (empty($api_key)) {
            throw new \Exception(
                'You must set a valid Google API key in the Calculator Settings area in order to access Google Sheets.'
            );
        }
        $client = new \Google_Client();
        $client->setDeveloperKey($api_key);
        $service = new \Google_Service_Sheets($client);

        try {
            $spreadsheet = $service->spreadsheets->get($sheet_id, array(
                'ranges' => $range,
                'includeGridData' => true
            ));
        } catch (\Exception $e) {
            throw new \Exception('Error retrieving data from Google Sheets.');
        }

        $r = array();
        foreach ($spreadsheet->sheets[$sheet_idx-1]->data[0]->rowData as $row) {
            $row_arr = array();
            foreach ($row->values as $cell) {
                if (!empty($cell->effectiveValue->numberValue) && empty($cell->effectiveValue->stringValue)) {
                    $row_arr[] = $cell->effectiveValue->numberValue;
                } else {
                    $row_arr[] = $cell->effectiveValue->stringValue;
                }
            }
            $r[] = $row_arr;
        }
        return $r;
    }

    /**
     * Obtain a range from an external spreadsheet.
     * The referenced spreadsheet could be a local file, a remote file URL, or a Google Sheets URL.
     * File type is automatically detected.
     * For supported file formats, see https://phpspreadsheet.readthedocs.io/en/develop/topics/file-formats/
     *
     * @param string $file
     * @param int $sheet_idx number of sheet in file [1..n]
     * @param string $range A1 notation
     * @return array[] 2-dimensional array of rows and cells
     * @since 1.3.0
     *
     */
    private function getRangeFromSpreadsheet($file, $sheet_idx, $range)
    {
        if (is_array($file)) {
            $file = array_shift($file);
        }

        if ((strpos($file, '://') === false) && is_file($file)) {
            // Local file
            // Check if allowed
            $local_allowed = wpSettingsFramework\wpsf_get_setting(self::SETTINGS_PAGE, 'features', 'allow_csv_local');
            if (!$local_allowed) {
                throw new \Exception(
                    'Referencing local spreadsheets not allowed, please check the calculator plugin settings.'
                );
            }
            $tmp_file = $file; // Open it directly
        } else {
            $url_components = parse_url($file);
            if ($url_components === false) {
                throw new \Exception('Referenced spreadsheet does not exist.');
            }

            // Apparently valid URL
            // Check if allowed
            $remote_allowed = wpSettingsFramework\wpsf_get_setting(self::SETTINGS_PAGE, 'features', 'allow_csv_remote');
            if (!$remote_allowed) {
                throw new \Exception(
                    'Referencing remote spreadsheets not allowed, please check the calculator plugin settings.'
                );
            }

            // Is it a Google spreadsheet?
            if (preg_match('/^https?\:\/\/docs\.google\.com\/spreadsheets\/d\/([a-z_\-0-9]+)/i', $file, $matches)) {
                return $this->getRangeFromGoogleSheet($matches[1], $sheet_idx, $range);
            }

            $tmp_file = $this->downloadSpreadsheet($file);
        }

        // Load file and get data
        $filterSubset = new SpreadsheetReadFilter($range);
        $reader = PhpSpreadsheet\IOFactory::createReaderForFile($tmp_file);
        $reader->setReadFilter($filterSubset);
        $reader->setReadDataOnly(true);
        $spreadsheet = $reader->load($tmp_file);
        $worksheet = $spreadsheet->getSheet($sheet_idx-1);

        list($rangeStart, $rangeEnd) = PhpSpreadsheet\Cell\Coordinate::rangeBoundaries($range);
        $r = array();
        for ($row = $rangeStart[1]; $row <= $rangeEnd[1]; $row++) {
            $row_arr = array();
            for ($col = $rangeStart[0]; $col <= $rangeEnd[0]; $col++) {
                $row_arr[] = $worksheet->getCellByColumnAndRow($col, $row)->getValue();
            }
            $r[] = $row_arr;
        }
        return $r;
    }

    /**
     * Obtain a value from an external spreadsheet.
     * The referenced spreadsheet could be a local file, a remote file URL, or a Google Sheets URL.
     * File type is automatically detected.
     * For supported file formats, see https://phpspreadsheet.readthedocs.io/en/develop/topics/file-formats/
     *
     * @param string $file
     * @param int $sheet_idx number of sheet in file [1..n]
     * @param int $column [1..n]
     * @param int $row [1..n]
     * @return mixed cell value
     * @since 1.3.0
     *
     */
    private function getValueFromSpreadsheet($file, $sheet_idx, $column, $row)
    {
        if ((strpos($file, '://') === false) && is_file($file)) {
            // Local file
            // Check if allowed
            $local_allowed = wpSettingsFramework\wpsf_get_setting(self::SETTINGS_PAGE, 'features', 'allow_csv_local');
            if (!$local_allowed) {
                throw new \Exception(
                    'Referencing local spreadsheets not allowed, please check the calculator plugin settings.'
                );
            }
            $tmp_file = $file; // Open it directly
        } else {
            $url_components = parse_url($file);
            if ($url_components === false) {
                throw new \Exception('Referenced spreadsheet does not exist.');
            }

            // Apparently valid URL
            // Check if allowed
            $remote_allowed = wpSettingsFramework\wpsf_get_setting(self::SETTINGS_PAGE, 'features', 'allow_csv_remote');
            if (!$remote_allowed) {
                throw new \Exception(
                    'Referencing remote spreadsheets not allowed, please check the calculator plugin settings.'
                );
            }

            // Is it a Google spreadsheet?
            if (preg_match('/^https?\:\/\/docs\.google\.com\/spreadsheets\/d\/([a-z_\-0-9]+)/i', $file, $matches)) {
                return $this->getValueFromGoogleSheet($matches[1], $sheet_idx, $column, $row);
            }

            $tmp_file = $this->downloadSpreadsheet($file);
        }

        // Load file and get data
        $filterSubset = new SpreadsheetReadFilter(array([$column, $row]));
        $reader = PhpSpreadsheet\IOFactory::createReaderForFile($tmp_file);
        $reader->setReadFilter($filterSubset);
        $reader->setReadDataOnly(true);
        $spreadsheet = $reader->load($tmp_file);
        $worksheet = $spreadsheet->getSheet($sheet_idx-1);
        $cellValue = $worksheet->getCellByColumnAndRow($column, $row)->getValue();
        return $cellValue;
    }

    /**
     * Processes a string with nested parentheses
     * and extracts part from the given starting position until the final closing parenthesis
     *
     * @param string $str
     * @param int $startPos initial string position
     * @param string $open opening parenthesis character
     * @param string $close closing parenthesis character
     * @return string
     * @since 1.2.0
     *
     */
    private function getStringUntilClosingParenthesis($str, $startPos, $open = '(', $close = ')')
    {

        list($str, $literals) = $this->popStringLiterals($str);

        if (function_exists('mb_strlen')) {
            // Make it Unicode-safe if possible
            $l = mb_strlen($str);
            $mb = true;
        } else {
            $l = strlen($str);
            $mb = false;
        }

        $depth = 0;
        $buffer = '';
        $found_closing = false;

        for ($i = $startPos; $i <= $l; $i++) {
            if ($mb) {
                $char = substr($str, $i, 1);
            } else {
                $char = mb_substr($str, $i, 1, 'utf-8');
            }
            if ($char == $open) {
                $depth++;
            } elseif ($char == $close) {
                if ($depth == 0) {
                    $found_closing = true;
                    break;
                } else {
                    $depth--;
                }
            }
            $buffer .= $char;
        }

        if ($found_closing == false) {
            throw new \Exception("Mismatched parentheses");
        }

        $r = $this->pushStringLiterals($buffer, $literals);
        return $r;
    }

    /**
     * Processes POST fields and does the calculations before CF7 gets them
     *
     * @since 1.0.0
     *
     */
    public function interceptSubmit()
    {
        if (!empty($_POST['_wpcf7']) && empty($_POST['pvb_form_id'])) {
            $form = WPCF7_ContactForm::get_instance((int)$_POST['_wpcf7']);
            if ($form !== false) {
                $input = $_POST;
                $r = $this->calculateForm($form, $input);
                if (is_array($r) && !empty($r)) {
                    foreach ($r as $key => $value) {
                        $_POST[$key] = (string)$value;
                    }
                }
            }
        }
    }

    /**
     * Load a view
     *
     * @param string $view Name of the file in the views subdirectory of the plugin.
     * @param array $data Arguments to make available to the view as PHP variables.
     * @since 1.0.0
     *
     */
    private function loadView($view, $data = array())
    {
        extract($data);
        $pluginVersion = $this->pluginVersion;
        include(PVB_CF7_CALCULATOR_PRO_PATH . '/views/' . $view . '.php');
    }

    /**
     * Extracts single- or double-quoted string literals from a string containing PHP code
     * Returns an array with two elements:
     *     [0] New string with literals replaced with markers (e.g. "STRING0", 'STRING1')
     *     [1] Array of strings corresponding to each marker, with original quotes
     *
     * @param string $string
     * @return array
     * @since 1.2.0
     *
     */
    private function popStringLiterals($string)
    {
        $literals = array();
        $counter = 0;
        $regex1 = '/(?<!\\\\)\'(.*?)(?<!\\\\)\'/';
        $regex2 = '/(?<!\\\\)"(.*?)(?<!\\\\)"/';
        $callback = function ($match) use (&$literals, &$counter) {
            $literals[$counter] = $match[0];
            $delimiter = substr($match[0], 0, 1);
            $r = "{$delimiter}#STRING{$counter}#{$delimiter}";
            $counter++;
            return $r;
        };
        $new_string = preg_replace_callback($regex1, $callback, $string);
        $new_string = preg_replace_callback($regex2, $callback, $new_string);
        return array($new_string, $literals);
    }

    /**
     * Reconstitutes strings with literals extracted by popStringLiterals
     *
     * @param string $string
     * @param array $literals
     * @return string
     * @since 1.2.0
     *
     */
    private function pushStringLiterals($string, $literals)
    {
        $regex = '/[\'"]#STRING([0-9]+)#[\'"]/';
        $callback = function ($match) use ($literals) {
            return $literals[$match[1]];
        };
        return preg_replace_callback($regex, $callback, $string);
    }

    /**
     * Replaces decimal and thousands separators
     *
     * @param string $value
     * @return string
     * @since 1.6.2
     *
     */
    private function replaceSeparators($value) {
        $decimal_separator = wpSettingsFramework\wpsf_get_setting(
            self::SETTINGS_PAGE,
            'features',
            'decimal_separator'
        );
        if (empty($decimal_separator)) {
            $decimal_separator = '.';
        }

        $thousands_separator = wpSettingsFramework\wpsf_get_setting(
            self::SETTINGS_PAGE,
            'features',
            'thousands_separator'
        );

        $value = str_replace($decimal_separator, '###DECIMAL###', $value);
        $value = str_replace($thousands_separator, '', $value);
        $value = str_replace('###DECIMAL###', '.', $value);
        return $value;
    }

    /**
     * Adds decimal and thousands separators
     *
     * @param float $value
     * @return string
     * @since 1.6.2
     *
     */
    private function addSeparators($value) {
        $decimal_separator = wpSettingsFramework\wpsf_get_setting(
            self::SETTINGS_PAGE,
            'features',
            'decimal_separator'
        );
        if (empty($decimal_separator)) {
            $decimal_separator = '.';
        }

        $thousands_separator = wpSettingsFramework\wpsf_get_setting(
            self::SETTINGS_PAGE,
            'features',
            'thousands_separator'
        );

        $decimals = strlen(substr(strrchr((string) $value, "."), 1));
        return number_format(
            (float) $value,
            $decimals,
            $decimal_separator,
            $thousands_separator
        );
    }

    /**
     * Replace input field names with posted data in the given string
     *
     * @param WPCF7_ContactForm $form
     * @param string $expression
     * @param string $input
     * @return string
     * @since 1.4.0
     *
     */
    private function replaceInputs($form, $expression, $input, $numeric = true, $escape = '') {
        // Order input variables from longest to shortest names
        $keys = array_keys($input);

        // Handle checkbox groups with nothing selected
        $tags = $form->scan_form_tags();
        foreach ($tags as $tag) {
            if ($tag['basetype'] == 'checkbox') {
                if (!in_array($tag['name'], $keys)) {
                    $keys[] = $tag['name'];
                }
            }
        }

        usort($keys, array($this, 'sortByLengthHelper'));

        // Replace input variables in equation
        date_default_timezone_set('UTC');
        foreach ($keys as $key) {
            if (is_array($input[$key])) {
                // Only one value?
                if (count($input[$key]) == 1) {
                    $input[$key] = $this->replaceSeparators(
                        array_shift($input[$key])
                    );
                } else {
                    // Sum values
                    $sum = 0;
                    foreach ($input[$key] as $value) {
                        $value = $this->replaceSeparators($value);
                        if (is_numeric($value)) {
                            $sum += $value;
                        }
                    }
                    $input[$key] = $sum;
                }
            }
            if (preg_match('/[0-9]{4}\-[0-9]{2}-[0-9]{2}/', $input[$key])) {
                // Date
                $days = intval(strtotime($input[$key])/86400);
                $expression = preg_replace(
                    '/(^|[^A-Za-z0-9])' . preg_quote($key, '/') . '($|[^A-Za-z0-9])/',
                    '$1###RPLC###$2',
                    $expression
                );
                $expression = str_replace("###RPLC###", $days, $expression);
            } else {
                // Not date
                if ($numeric == false) {
                    $num = $input[$key];
                    if (!empty($escape)) {
                        $num = addcslashes($num, $escape);
                    }
                } elseif (is_numeric($this->replaceSeparators($input[$key]))) {
                    $num = $this->replaceSeparators($input[$key]);
                } else {
                    $num = 0;
                }
                $expression = preg_replace(
                    '/(^|[^A-Za-z0-9])' . preg_quote($key, '/') . '($|[^A-Za-z0-9])/',
                    '$1###RPLC###$2',
                    $expression
                );
                $expression = str_replace("###RPLC###", $num, $expression);
            }
        }
        return $expression;
    }

    /**
     *
     * @since 1.0.0
     *
     */
    private function sortByLengthHelper($a, $b)
    {
        return strlen($b)-strlen($a);
    }

    /**
     * Display spreadsheet dropdown list
     *
     * @param WPCF7_FormTag $tag
     * @return string
     * @since 1.6.4
     *
     */
    private function spreadsheetListDropDown($tag, $labels, $values)
    {
        $validation_error = wpcf7_get_validation_error($tag->name);

        $class = wpcf7_form_controls_class(
            $tag->type,
            'wpcf7-spreadsheet_list'
        );

        if ($validation_error) {
            $class .= ' wpcf7-not-valid';
        }

        $atts = array();

        $atts['class'] = $tag->get_class_option($class);
        $atts['id'] = $tag->get_id_option();
        $atts['tabindex'] = $tag->get_option('tabindex', 'signed_int', true);

        if ($tag->is_required()) {
            $atts['aria-required'] = 'true';
        }

        $atts['aria-invalid'] = $validation_error ? 'true' : 'false';

        $multiple = $tag->has_option('multiple');
        $include_blank = $tag->has_option('include_blank');
        $first_as_label = $tag->has_option('first_as_label');

        if ($tag->has_option('size')) {
            $size = $tag->get_option('size', 'int', true);

            if ($size) {
                $atts['size'] = $size;
            } elseif ($multiple) {
                $atts['size'] = 4;
            } else {
                $atts['size'] = 1;
            }
        }

        if ($data = (array)$tag->get_data_option()) {
            $values = array_merge($values, array_values($data));
            $labels = array_merge($labels, array_values($data));
        }

        $defaults = array();

        $default_choice = $tag->get_default_option(null, 'multiple=1');

        foreach ($default_choice as $value) {
            $key = array_search($value, $values, true);

            if (false !== $key) {
                $defaults[] = (int)$key + 1;
            }
        }

        if ($matches = $tag->get_first_match_option('/^default:([0-9_]+)$/')) {
            $defaults = array_merge($defaults, explode('_', $matches[1]));
        }

        $defaults = array_unique($defaults);

        $shifted = false;

        if ($include_blank || empty($values)) {
            array_unshift($labels, '---');
            array_unshift($values, '');
            $shifted = true;
        } elseif ($first_as_label) {
            $values[0] = '';
        }

        $html = '';
        $hangover = wpcf7_get_hangover($tag->name);

        foreach ($values as $key => $value) {
            $selected = false;

            if ($hangover) {
                if ($multiple) {
                    $selected = in_array($value, (array)$hangover, true);
                } else {
                    $selected = ($hangover === $value);
                }
            } else {
                if (!$shifted && in_array((int)$key + 1, (array)$defaults)) {
                    $selected = true;
                } elseif ($shifted && in_array((int) $key, (array)$defaults)) {
                    $selected = true;
                }
            }

            $item_atts = array(
                'value' => $value,
                'selected' => $selected ? 'selected' : '',
            );

            $item_atts = wpcf7_format_atts($item_atts);

            $label = isset($labels[$key]) ? $labels[$key] : $value;

            $html .= sprintf(
                '<option %1$s>%2$s</option>',
                $item_atts,
                esc_html($label)
            );
        }

        if ($multiple) {
            $atts['multiple'] = 'multiple';
        }

        $atts['name'] = $tag->name . ($multiple ? '[]' : '');

        $atts = wpcf7_format_atts($atts);

        $html = sprintf(
            '<span class="wpcf7-form-control-wrap %1$s"><select %2$s>%3$s</select>%4$s</span>',
            sanitize_html_class($tag->name),
            $atts,
            $html,
            $validation_error
        );

        return $html;
    }

    /**
     * Display spreadsheet checkboxes list
     *
     * @param WPCF7_FormTag $tag
     * @return string
     * @since 1.6.4
     *
     */
    private function spreadsheetListCheckboxes($tag, $labels, $values)
    {
        $validation_error = wpcf7_get_validation_error( $tag->name );

        $class = wpcf7_form_controls_class($tag->type);

        if ($validation_error) {
            $class .= ' wpcf7-not-valid';
        }

        $label_first = $tag->has_option('label_first');
        $use_label_element = $tag->has_option('use_label_element');
        $exclusive = !$tag->has_option('multiple');
        $free_text = $tag->has_option('free_text');
        $multiple = false;

        $multiple = !$exclusive;

        if ($exclusive) {
            $class .= ' wpcf7-exclusive-checkbox';
        }

        $atts = array();

        $atts['class'] = $tag->get_class_option($class);
        $atts['id'] = $tag->get_id_option();

        $tabindex = $tag->get_option('tabindex', 'signed_int', true);

        if (false !== $tabindex) {
            $tabindex = (int) $tabindex;
        }

        $html = '';
        $count = 0;

        if ($data = (array) $tag->get_data_option()) {
            if ( $free_text ) {
                $values = array_merge(
                    array_slice($values, 0, -1 ),
                    array_values($data),
                    array_slice($values, -1));
                $labels = array_merge(
                    array_slice($labels, 0, -1),
                    array_values($data),
                    array_slice($labels, -1));
            } else {
                $values = array_merge($values, array_values($data));
                $labels = array_merge($labels, array_values($data));
            }
        }

        $defaults = array();

        $default_choice = $tag->get_default_option(null, 'multiple=1');

        foreach ($default_choice as $value) {
            $key = array_search($value, $values, true);

            if (false !== $key) {
                $defaults[] = (int) $key + 1;
            }
        }

        if ($matches = $tag->get_first_match_option( '/^default:([0-9_]+)$/')) {
            $defaults = array_merge($defaults, explode('_', $matches[1]));
        }

        $defaults = array_unique($defaults);

        $hangover = wpcf7_get_hangover($tag->name, $multiple ? array() : '');

        foreach ($values as $key => $value) {
            $class = 'wpcf7-list-item';

            $checked = false;

            if ($hangover) {
                if ($multiple) {
                    $checked = in_array($value, (array) $hangover, true);
                } else {
                    $checked = ($hangover === $value);
                }
            } else {
                $checked = in_array($key + 1, (array) $defaults);
            }

            if (isset($labels[$key])) {
                $label = $labels[$key];
            } else {
                $label = $value;
            }

            $item_atts = array(
                'type' => 'checkbox',
                'name' => $tag->name . ($multiple ? '[]' : ''),
                'value' => $value,
                'checked' => $checked ? 'checked' : '',
                'tabindex' => false !== $tabindex ? $tabindex : '',
            );

            $item_atts = wpcf7_format_atts($item_atts);

            if ($label_first) { // put label first, input last
                $item = sprintf(
                    '<span class="wpcf7-list-item-label">%1$s</span>' .
                        '<input %2$s />',
                    esc_html($label), $item_atts);
            } else {
                $item = sprintf(
                    '<input %2$s />' .
                        '<span class="wpcf7-list-item-label">%1$s</span>',
                    esc_html($label), $item_atts);
            }

            if ($use_label_element) {
                $item = '<label>' . $item . '</label>';
            }

            if (false !== $tabindex && 0 < $tabindex) {
                $tabindex += 1;
            }

            $count += 1;

            if (1 == $count) {
                $class .= ' first';
            }

            if (count($values) == $count) { // last round
                $class .= ' last';

                if ($free_text) {
                    $free_text_name = sprintf(
                        '_wpcf7_%1$s_free_text_%2$s', 'checkbox', $tag->name);

                    $free_text_atts = array(
                        'name' => $free_text_name,
                        'class' => 'wpcf7-free-text',
                        'tabindex' => false !== $tabindex ? $tabindex : '',
                    );

                    if (wpcf7_is_posted() && isset($_POST[$free_text_name])) {
                        $free_text_atts['value'] = wp_unslash(
                            $_POST[$free_text_name] );
                    }

                    $free_text_atts = wpcf7_format_atts($free_text_atts);

                    $item .= sprintf(
                        ' <input type="text" %s />',
                        $free_text_atts
                    );

                    $class .= ' has-free-text';
                }
            }

            $item = '<span class="' . esc_attr($class) . '">' .
                $item . '</span>';
            $html .= $item;
        }

        $atts = wpcf7_format_atts( $atts );

        $html = sprintf(
            '<span class="wpcf7-form-control-wrap %1$s">' . 
                '<span %2$s>%3$s</span>%4$s</span>',
            sanitize_html_class($tag->name), $atts, $html, $validation_error);

        return $html;
    }

    /**
     * Display spreadsheet radio button list
     *
     * @param WPCF7_FormTag $tag
     * @return string
     * @since 1.6.4
     *
     */
    private function spreadsheetListRadio($tag, $labels, $values)
    {
        $validation_error = wpcf7_get_validation_error( $tag->name );

        $class = wpcf7_form_controls_class($tag->type);

        if ($validation_error) {
            $class .= ' wpcf7-not-valid';
        }

        $label_first = $tag->has_option('label_first');
        $use_label_element = $tag->has_option('use_label_element');
        $free_text = $tag->has_option('free_text');

        $atts = array();

        $atts['class'] = $tag->get_class_option($class);
        $atts['id'] = $tag->get_id_option();

        $tabindex = $tag->get_option('tabindex', 'signed_int', true);

        if (false !== $tabindex) {
            $tabindex = (int) $tabindex;
        }

        $html = '';
        $count = 0;

        if ($data = (array) $tag->get_data_option()) {
            if ( $free_text ) {
                $values = array_merge(
                    array_slice($values, 0, -1 ),
                    array_values($data),
                    array_slice($values, -1));
                $labels = array_merge(
                    array_slice($labels, 0, -1),
                    array_values($data),
                    array_slice($labels, -1));
            } else {
                $values = array_merge($values, array_values($data));
                $labels = array_merge($labels, array_values($data));
            }
        }

        $defaults = array();

        $default_choice = $tag->get_default_option(null, 'multiple=1');

        foreach ($default_choice as $value) {
            $key = array_search($value, $values, true);

            if (false !== $key) {
                $defaults[] = (int) $key + 1;
            }
        }

        if ($matches = $tag->get_first_match_option( '/^default:([0-9_]+)$/')) {
            $defaults = array_merge($defaults, explode('_', $matches[1]));
        }

        $defaults = array_unique($defaults);

        $hangover = wpcf7_get_hangover($tag->name, '');

        foreach ($values as $key => $value) {
            $class = 'wpcf7-list-item';

            $checked = false;

            if ($hangover) {
                $checked = ($hangover === $value);
            } else {
                $checked = in_array($key + 1, (array) $defaults);
            }

            if (isset($labels[$key])) {
                $label = $labels[$key];
            } else {
                $label = $value;
            }

            $item_atts = array(
                'type' => 'radio',
                'name' => $tag->name,
                'value' => $value,
                'checked' => $checked ? 'checked' : '',
                'tabindex' => false !== $tabindex ? $tabindex : '',
            );

            $item_atts = wpcf7_format_atts($item_atts);

            if ($label_first) { // put label first, input last
                $item = sprintf(
                    '<span class="wpcf7-list-item-label">%1$s</span>' .
                        '<input %2$s />',
                    esc_html($label), $item_atts);
            } else {
                $item = sprintf(
                    '<input %2$s />' .
                        '<span class="wpcf7-list-item-label">%1$s</span>',
                    esc_html($label), $item_atts);
            }

            if ($use_label_element) {
                $item = '<label>' . $item . '</label>';
            }

            if (false !== $tabindex && 0 < $tabindex) {
                $tabindex += 1;
            }

            $count += 1;

            if (1 == $count) {
                $class .= ' first';
            }

            if (count($values) == $count) { // last round
                $class .= ' last';

                if ($free_text) {
                    $free_text_name = sprintf(
                        '_wpcf7_%1$s_free_text_%2$s', 'radio', $tag->name);

                    $free_text_atts = array(
                        'name' => $free_text_name,
                        'class' => 'wpcf7-free-text',
                        'tabindex' => false !== $tabindex ? $tabindex : '',
                    );

                    if (wpcf7_is_posted() && isset($_POST[$free_text_name])) {
                        $free_text_atts['value'] = wp_unslash(
                            $_POST[$free_text_name] );
                    }

                    $free_text_atts = wpcf7_format_atts($free_text_atts);

                    $item .= sprintf(
                        ' <input type="text" %s />',
                        $free_text_atts
                    );

                    $class .= ' has-free-text';
                }
            }

            $item = '<span class="' . esc_attr($class) . '">' .
                $item . '</span>';
            $html .= $item;
        }

        $atts = wpcf7_format_atts( $atts );

        $html = sprintf(
            '<span class="wpcf7-form-control-wrap %1$s">' . 
                '<span %2$s>%3$s</span>%4$s</span>',
            sanitize_html_class($tag->name), $atts, $html, $validation_error);

        return $html;    }
}
